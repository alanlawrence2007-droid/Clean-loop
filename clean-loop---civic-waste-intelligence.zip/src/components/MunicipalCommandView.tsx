import React, { useState } from 'react';
import { CompactorTruck, GrievanceTicket, WardMetric } from '../types';
import { INITIAL_TRUCKS, INITIAL_WARDS, INITIAL_GRIEVANCES } from '../data/mockMunicipalData';

export const MunicipalCommandView: React.FC = () => {
  const [trucks, setTrucks] = useState<CompactorTruck[]>(INITIAL_TRUCKS);
  const [selectedTruck, setSelectedTruck] = useState<CompactorTruck>(INITIAL_TRUCKS[0]);
  const [grievances, setGrievances] = useState<GrievanceTicket[]>(INITIAL_GRIEVANCES);
  const [rerouteNotification, setRerouteNotification] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'fleet' | 'weighbridge' | 'grievances' | 'wards'>('fleet');

  const handleTriggerReroute = () => {
    setRerouteNotification('Automated Compactor Routing triggered! Truck #MH-02-CW-4412 diverted to Sector 9 Market Surge.');
    setTrucks((prev) =>
      prev.map((t) =>
        t.id === 'trk-4412'
          ? { ...t, activeLane: 'Re-routed: Gulmohar Market Surge Priority Lane', etaMinutes: 3 }
          : t
      )
    );
    setTimeout(() => setRerouteNotification(null), 5000);
  };

  const handleApproveGrievance = (id: string) => {
    setGrievances((prev) =>
      prev.map((g) => (g.id === id ? { ...g, status: 'verified_resolved', inspectorApproved: true } : g))
    );
  };

  const handleRejectGrievance = (id: string) => {
    setGrievances((prev) =>
      prev.map((g) =>
        g.id === id
          ? {
              ...g,
              status: 'assigned',
              disputeNotes: 'Contractor cleanup rejected: Residue visible on curb. Penalty of ₹2,500 levied.'
            }
          : g
      )
    );
  };

  return (
    <div className="w-full min-h-[calc(100vh-80px)] bg-[#e8fef4] py-8 px-4 md:px-8 lg:px-12 flex flex-col gap-6">
      <div className="max-w-7xl mx-auto w-full flex flex-col gap-6">
        {/* Header Console Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-5 rounded-3xl shadow-sm border border-[#c0c8c4]/30">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-[#0b3d32] flex items-center justify-center text-[#c5f26a]">
              <span className="material-symbols-outlined text-[26px]">hub</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-['Sora'] text-xl font-bold text-[#00261e]">
                  Central MSW Command Matrix
                </h2>
                <span className="bg-[#d7ede3] text-[#00261e] text-[10px] font-bold font-['Sora'] px-2 py-0.5 rounded">
                  Cluster South-04
                </span>
              </div>
              <p className="font-['Manrope'] text-xs text-[#404945]">
                Greater Mumbai Solid Waste Management & Telemetry Verification Engine
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 bg-[#e2f9ef] px-3 py-1.5 rounded-full border border-[#c0c8c4]/30">
              <span className="w-2.5 h-2.5 rounded-full bg-[#4a6700] animate-pulse"></span>
              <span className="font-['Sora'] text-xs font-bold text-[#00261e]">
                Live Satellite Pings: 14 Trucks
              </span>
            </div>
            <button
              onClick={handleTriggerReroute}
              className="bg-[#0b3d32] text-[#c5f26a] hover:bg-[#00261e] px-4 py-2 rounded-xl text-xs font-bold font-['Manrope'] shadow-sm transition-all flex items-center gap-1.5"
            >
              <span className="material-symbols-outlined text-[16px]">alt_route</span>
              <span>Trigger Market Reroute</span>
            </button>
          </div>
        </div>

        {rerouteNotification && (
          <div className="bg-[#0b3d32] text-[#c5f26a] p-3.5 rounded-2xl text-xs font-['Manrope'] font-bold flex items-center justify-between border border-[#c5f26a]/40 animate-in fade-in">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[18px]">emergency</span>
              <span>{rerouteNotification}</span>
            </div>
            <button onClick={() => setRerouteNotification(null)} className="text-white hover:underline">
              Dismiss
            </button>
          </div>
        )}

        {/* Section Navigation */}
        <div className="flex items-center gap-2 border-b border-[#c0c8c4]/30 pb-2">
          <button
            onClick={() => setActiveTab('fleet')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold font-['Manrope'] transition-all ${
              activeTab === 'fleet' ? 'bg-[#00261e] text-[#c5f26a]' : 'text-[#404945] hover:bg-white'
            }`}
          >
            Fleet GPS & Raw Telemetry
          </button>
          <button
            onClick={() => setActiveTab('weighbridge')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold font-['Manrope'] transition-all ${
              activeTab === 'weighbridge' ? 'bg-[#00261e] text-[#c5f26a]' : 'text-[#404945] hover:bg-white'
            }`}
          >
            MRF Weighbridge Verification
          </button>
          <button
            onClick={() => setActiveTab('grievances')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold font-['Manrope'] transition-all ${
              activeTab === 'grievances' ? 'bg-[#00261e] text-[#c5f26a]' : 'text-[#404945] hover:bg-white'
            }`}
          >
            Dual-Party Grievance Sign-Off ({grievances.filter((g) => g.status === 'fix_proposed').length})
          </button>
          <button
            onClick={() => setActiveTab('wards')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold font-['Manrope'] transition-all ${
              activeTab === 'wards' ? 'bg-[#00261e] text-[#c5f26a]' : 'text-[#404945] hover:bg-white'
            }`}
          >
            Ward Cleanliness League
          </button>
        </div>

        {/* TAB 1: FLEET TELEMETRY */}
        {activeTab === 'fleet' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Trucks List */}
            <div className="lg:col-span-5 flex flex-col gap-3">
              <span className="font-['Sora'] text-xs font-bold text-[#00261e] uppercase">
                Active Ward 12 Compactor Beats
              </span>
              {trucks.map((trk) => {
                const isSelected = selectedTruck.id === trk.id;
                return (
                  <div
                    key={trk.id}
                    onClick={() => setSelectedTruck(trk)}
                    className={`p-4 rounded-2xl cursor-pointer transition-all border ${
                      isSelected
                        ? 'bg-white border-[#0b3d32] shadow-md'
                        : 'bg-white/80 border-[#c0c8c4]/30 hover:bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-['Sora'] text-sm font-bold text-[#00261e]">
                          {trk.registrationNumber}
                        </span>
                        <span className="text-[11px] font-['Manrope'] text-[#404945]">
                          ({trk.sector})
                        </span>
                      </div>
                      <span
                        className={`text-[10px] font-bold font-['Sora'] px-2 py-0.5 rounded-full ${
                          trk.isGhostFleetWarning
                            ? 'bg-[#ffdad6] text-[#ba1a1a]'
                            : 'bg-[#e2f9ef] text-[#4a6700]'
                        }`}
                      >
                        {trk.isGhostFleetWarning ? 'SIGNAL STALL (RULE 02)' : 'ACTIVE PINGS'}
                      </span>
                    </div>

                    <div className="text-xs font-['Manrope'] text-[#404945] mb-2">{trk.activeLane}</div>

                    {/* Progress Bar */}
                    <div className="w-full bg-[#e2f9ef] h-2 rounded-full overflow-hidden mb-2">
                      <div
                        className="bg-[#0b3d32] h-full"
                        style={{ width: `${trk.clearedPercentage}%` }}
                      ></div>
                    </div>

                    <div className="flex items-center justify-between text-[11px] font-['Manrope'] text-[#404945]">
                      <span>ETA: {trk.etaMinutes} mins</span>
                      <span>Purity: {trk.wetPurityScore}%</span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Selected Truck Detail Viewport */}
            <div className="lg:col-span-7 bg-white rounded-3xl p-6 shadow-md border border-[#c0c8c4]/30 flex flex-col gap-5">
              <div className="flex items-center justify-between border-b border-[#c0c8c4]/20 pb-3">
                <div>
                  <h3 className="font-['Sora'] text-lg font-bold text-[#00261e]">
                    Compactor {selectedTruck.registrationNumber} Telemetry Stream
                  </h3>
                  <span className="font-['Manrope'] text-xs text-[#404945]">
                    Operator: {selectedTruck.driver} · Ward 12 Beat 4
                  </span>
                </div>
                <div className="text-right">
                  <div className="font-['Sora'] text-xs font-bold text-[#00261e]">Next Weighbridge:</div>
                  <div className="font-['Manrope'] text-xs text-[#4a6700] font-semibold">
                    {selectedTruck.nextCheckpoint}
                  </div>
                </div>
              </div>

              {/* Simulated Map Visualizer */}
              <div className="w-full h-64 bg-[#00261e] rounded-2xl relative overflow-hidden flex flex-col justify-between p-4 text-white">
                <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#c5f26a_1px,transparent_1px)] [background-size:16px_16px]"></div>

                <div className="relative z-10 flex items-center justify-between">
                  <span className="bg-black/60 px-2.5 py-1 rounded text-[11px] font-mono text-[#c5f26a]">
                    RAW GPS: {selectedTruck.lastPingTimestamp}
                  </span>
                  <span className="bg-black/60 px-2 py-0.5 rounded text-[10px] font-['Sora'] text-white">
                    MAP TILE: GREATER MUMBAI K/WEST
                  </span>
                </div>

                {/* Simulated Truck Location Point */}
                <div className="relative z-10 flex flex-col items-center my-auto">
                  <div className="w-12 h-12 rounded-full bg-[#c5f26a]/20 border border-[#c5f26a] flex items-center justify-center animate-ping absolute"></div>
                  <div className="w-10 h-10 rounded-full bg-[#0b3d32] border-2 border-[#c5f26a] flex items-center justify-center text-[#c5f26a] shadow-lg relative z-10">
                    <span className="material-symbols-outlined text-[20px]">local_shipping</span>
                  </div>
                  <span className="mt-2 text-xs font-['Sora'] font-bold bg-black/80 px-2 py-0.5 rounded text-[#c5f26a]">
                    {selectedTruck.registrationNumber} (ETA {selectedTruck.etaMinutes}m)
                  </span>
                </div>

                <div className="relative z-10 flex items-center justify-between text-xs text-[#e0f6ec]">
                  <span>Purity Index: {selectedTruck.wetPurityScore}%</span>
                  <span>{selectedTruck.clearedPercentage}% Bin Stops Cleared</span>
                </div>
              </div>

              {/* Anti-Ghost Fleet Explanation */}
              <div className="bg-[#e2f9ef] p-4 rounded-xl flex items-start gap-3 text-xs font-['Manrope'] text-[#00261e]">
                <span className="material-symbols-outlined text-[#4a6700] text-[20px] shrink-0 mt-0.5">
                  verified
                </span>
                <div>
                  <strong>Clean-Loop Rule 02 Guarantee:</strong> Unlike legacy municipal dashboards that interpolate smooth synthetic routes when vehicles stall, Clean-Loop halts vehicle progress display during signal dropouts to prevent contractor falsification.
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: WEIGHBRIDGE MRF VERIFICATION */}
        {activeTab === 'weighbridge' && (
          <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-md border border-[#c0c8c4]/30 flex flex-col gap-5">
            <div>
              <h3 className="font-['Sora'] text-xl font-bold text-[#00261e]">
                MRF Weighbridge Verification Log
              </h3>
              <p className="font-['Manrope'] text-xs text-[#404945]">
                Cryptographically audited gross/tare vehicle loads and optical purity scans before landfill or composting tipping.
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-['Manrope']">
                <thead>
                  <tr className="border-b border-[#c0c8c4]/30 text-[#404945] font-['Sora'] font-bold">
                    <th className="py-3 px-2">Truck Plate</th>
                    <th className="py-3 px-2">Checkpoint Hub</th>
                    <th className="py-3 px-2">Gross Load</th>
                    <th className="py-3 px-2">Tare (Empty)</th>
                    <th className="py-3 px-2">Net Waste Tipped</th>
                    <th className="py-3 px-2">Optical Purity</th>
                    <th className="py-3 px-2">Ledger Verification</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#c0c8c4]/20">
                  <tr>
                    <td className="py-3 px-2 font-bold text-[#00261e]">MH-02-CW-4412</td>
                    <td className="py-3 px-2">MRF-3 Ghatkopar</td>
                    <td className="py-3 px-2">14.28 Tonnes</td>
                    <td className="py-3 px-2">6.12 Tonnes</td>
                    <td className="py-3 px-2 font-bold text-[#00261e]">8.16 Tonnes (Wet)</td>
                    <td className="py-3 px-2 text-[#4a6700] font-bold">92.4% Clean</td>
                    <td className="py-3 px-2 font-mono text-[10px] text-[#0b3d32]">
                      SHA256: 4f1a...92b
                    </td>
                  </tr>
                  <tr>
                    <td className="py-3 px-2 font-bold text-[#00261e]">MH-02-CW-8821</td>
                    <td className="py-3 px-2">MRF-2 Malad Hub</td>
                    <td className="py-3 px-2">12.80 Tonnes</td>
                    <td className="py-3 px-2">5.90 Tonnes</td>
                    <td className="py-3 px-2 font-bold text-[#00261e]">6.90 Tonnes (Dry)</td>
                    <td className="py-3 px-2 text-[#4a6700] font-bold">88.1% Clean</td>
                    <td className="py-3 px-2 font-mono text-[10px] text-[#0b3d32]">
                      SHA256: e82c...710
                    </td>
                  </tr>
                  <tr>
                    <td className="py-3 px-2 font-bold text-[#00261e]">MH-02-CW-3301</td>
                    <td className="py-3 px-2">Deonar Bio-Plant</td>
                    <td className="py-3 px-2">18.10 Tonnes</td>
                    <td className="py-3 px-2">7.20 Tonnes</td>
                    <td className="py-3 px-2 font-bold text-[#00261e]">10.90 Tonnes</td>
                    <td className="py-3 px-2 text-[#ba1a1a] font-bold">74.2% (Flagged)</td>
                    <td className="py-3 px-2 font-mono text-[10px] text-[#ba1a1a]">
                      Penalty Audit Pending
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 3: DUAL-PARTY GRIEVANCE SIGN-OFF */}
        {activeTab === 'grievances' && (
          <div className="flex flex-col gap-6">
            <div className="bg-white rounded-3xl p-6 shadow-md border border-[#c0c8c4]/30 flex flex-col gap-4">
              <div>
                <h3 className="font-['Sora'] text-xl font-bold text-[#00261e]">
                  Dual-Party Grievance Verification Console
                </h3>
                <p className="font-['Manrope'] text-xs text-[#404945]">
                  Rule 03 Enforced: Inspect contractor cleanup evidence against citizen complaint photo before marking resolved and paying fleet invoice.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {grievances.map((grv) => (
                  <div
                    key={grv.id}
                    className="bg-[#e8fef4] rounded-2xl p-5 flex flex-col justify-between gap-4 border border-[#c0c8c4]/40"
                  >
                    <div className="flex flex-col gap-2">
                      <div className="flex items-center justify-between">
                        <span className="font-['Sora'] text-xs font-bold text-[#00261e]">{grv.id}</span>
                        <span
                          className={`text-[10px] font-bold font-['Sora'] px-2.5 py-0.5 rounded-full ${
                            grv.status === 'verified_resolved'
                              ? 'bg-[#2E9E5B] text-white'
                              : 'bg-yellow-100 text-yellow-800'
                          }`}
                        >
                          {grv.status === 'verified_resolved' ? 'VERIFIED RESOLVED' : 'FIX PROPOSED'}
                        </span>
                      </div>

                      <div className="font-['Sora'] text-sm font-semibold text-[#00261e]">
                        {grv.category}
                      </div>
                      <div className="font-['Manrope'] text-xs text-[#404945]">{grv.location}</div>

                      {/* Photo Comparison */}
                      <div className="grid grid-cols-2 gap-2 mt-2">
                        <div className="flex flex-col gap-1">
                          <span className="text-[10px] font-['Sora'] font-bold text-[#404945]">
                            Citizen Photo (Reported)
                          </span>
                          <img
                            src={grv.citizenPhotoUrl}
                            alt="Citizen report"
                            className="w-full h-28 object-cover rounded-xl"
                          />
                        </div>
                        <div className="flex flex-col gap-1">
                          <span className="text-[10px] font-['Sora'] font-bold text-[#404945]">
                            Contractor Photo (After)
                          </span>
                          {grv.contractorPhotoUrl ? (
                            <img
                              src={grv.contractorPhotoUrl}
                              alt="Contractor proof"
                              className="w-full h-28 object-cover rounded-xl"
                            />
                          ) : (
                            <div className="w-full h-28 bg-[#ddf3e9] rounded-xl flex items-center justify-center text-xs text-[#404945]">
                              Pending Upload
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="text-[11px] font-['Manrope'] text-[#404945] bg-white p-2.5 rounded-xl border border-[#c0c8c4]/30 mt-1">
                        <strong>Notes:</strong> {grv.disputeNotes}
                      </div>
                    </div>

                    {grv.status === 'fix_proposed' && (
                      <div className="flex items-center gap-2 pt-2 border-t border-[#c0c8c4]/30">
                        <button
                          onClick={() => handleApproveGrievance(grv.id)}
                          className="flex-1 bg-[#0b3d32] text-[#c5f26a] hover:bg-[#00261e] py-2 rounded-xl text-xs font-bold transition-all"
                        >
                          Approve Sign-Off
                        </button>
                        <button
                          onClick={() => handleRejectGrievance(grv.id)}
                          className="flex-1 bg-[#ba1a1a] text-white hover:bg-[#93000a] py-2 rounded-xl text-xs font-bold transition-all"
                        >
                          Reject & Fine (₹2,500)
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: WARD CLEANLINESS LEAGUE */}
        {activeTab === 'wards' && (
          <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-md border border-[#c0c8c4]/30 flex flex-col gap-5">
            <div>
              <h3 className="font-['Sora'] text-xl font-bold text-[#00261e]">
                Comparative Ward Purity Matrix
              </h3>
              <p className="font-['Manrope'] text-xs text-[#404945]">
                Cross-ward analytics computed from physical weighbridge receipts and optical sorting sensors.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {INITIAL_WARDS.map((w) => (
                <div
                  key={w.wardId}
                  className="bg-[#e8fef4] p-5 rounded-2xl flex flex-col justify-between gap-3 border border-[#c0c8c4]/30"
                >
                  <div className="flex flex-col gap-1">
                    <span className="font-['Sora'] text-xs font-bold text-[#4a6700]">{w.wardId}</span>
                    <h4 className="font-['Sora'] text-sm font-bold text-[#00261e]">{w.name}</h4>
                  </div>

                  <div className="flex flex-col gap-2 pt-2 border-t border-[#c0c8c4]/30 text-xs font-['Manrope']">
                    <div className="flex justify-between">
                      <span className="text-[#404945]">Segregation:</span>
                      <strong className="text-[#00261e]">{w.segregationRate}%</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#404945]">Purity Score:</span>
                      <strong className="text-[#4a6700]">{w.purityScore}%</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#404945]">Daily Tonnage:</span>
                      <span>{w.dailyTonnage} T</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#404945]">SLA Resolution:</span>
                      <strong className="text-[#00261e]">{w.slaResolutionRate}%</strong>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
