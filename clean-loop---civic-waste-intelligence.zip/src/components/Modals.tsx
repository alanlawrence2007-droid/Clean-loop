import React, { useState } from 'react';

interface DemoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DemoModal: React.FC<DemoModalProps> = ({ isOpen, onClose }) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [activeChapter, setActiveChapter] = useState(0);

  if (!isOpen) return null;

  const chapters = [
    { title: 'Edge Optical Scan at Household', timestamp: '00:15', note: 'Bounding box inference & local by-law check' },
    { title: 'Weighbridge Gross & Tare Telemetry', timestamp: '00:48', note: 'Cryptographic load verification at MRF' },
    { title: 'Anti-Ghost Fleet Real-Time GPS', timestamp: '01:22', note: 'Distinguishing raw satellite pings vs stalls' },
    { title: 'Dual-Party Grievance Sign-Off', timestamp: '01:55', note: 'Citizen photo stamp veto before billing' }
  ];

  return (
    <div
      className="fixed inset-0 z-50 bg-[#00261e]/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in"
      onClick={onClose}
    >
      <div
        className="bg-[#ffffff] rounded-2xl max-w-3xl w-full p-6 flex flex-col gap-5 shadow-2xl relative border border-[#c0c8c4]/30"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#4a6700] text-[24px]">play_circle</span>
            <h3 className="font-['Sora'] font-semibold text-lg text-[#00261e]">
              Clean-Loop 2-Minute Architecture Walkthrough
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#ddf3e9] flex items-center justify-center text-[#0c1f19] hover:bg-[#d7ede3] transition-colors"
            type="button"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>

        {/* Video Player Mock with live animation */}
        <div className="w-full aspect-video bg-[#0b3d32] rounded-xl flex flex-col items-center justify-center relative overflow-hidden text-center p-6 text-white shadow-inner">
          <img
            className="absolute inset-0 w-full h-full object-cover opacity-35"
            alt="Municipal control room"
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuBoaQlM8ErcRyjvHp8aaxWO0GuL3C1WNOOE6H7l5h1n1asOg_4Bd6qkCCMgHLK6U4vayF9IU9fRaKxPIT9xNn82G-mug70aEcspzXIbEy7oXMLARq7F2cRuXZRip9GbLCIIwFuwz8I5l85g4sa40b7g-UhlOzmgfUscvYaBq_ThSbKutu-qljry4t2UCr4oTsL6XMqZEdwR2Git_cdEAn0aF8Zs7A1H3ktv3nKgyvJ4qw2z_wNjBuptPQ"
          />

          <div className="relative z-10 flex flex-col items-center gap-3">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="w-16 h-16 rounded-full bg-[#c5f26a] text-[#00261e] flex items-center justify-center shadow-lg hover:scale-105 active:scale-95 transition-all"
            >
              <span className="material-symbols-outlined text-[36px]">
                {isPlaying ? 'pause' : 'play_arrow'}
              </span>
            </button>
            <div className="font-['Sora'] font-semibold text-base sm:text-lg">
              Civic Segregation to Weighbridge Ledger
            </div>
            <span className="font-['Manrope'] text-xs sm:text-sm text-[#e0f6ec]">
              {chapters[activeChapter].title} — {chapters[activeChapter].note}
            </span>
          </div>

          {/* Interactive Scrub Bar */}
          <div className="absolute bottom-3 left-4 right-4 z-10 flex flex-col gap-1.5">
            <div className="w-full bg-white/20 h-1.5 rounded-full overflow-hidden cursor-pointer flex">
              <div
                className="bg-[#c5f26a] h-full transition-all duration-300"
                style={{ width: `${(activeChapter + 1) * 25}%` }}
              ></div>
            </div>
            <div className="flex justify-between text-[11px] text-[#e0f6ec] font-['Sora']">
              <span>{chapters[activeChapter].timestamp}</span>
              <span>02:14</span>
            </div>
          </div>
        </div>

        {/* Chapters list */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
          {chapters.map((chap, idx) => (
            <button
              key={idx}
              onClick={() => setActiveChapter(idx)}
              className={`p-2 rounded-lg text-left text-xs transition-all border ${
                activeChapter === idx
                  ? 'bg-[#ddf3e9] border-[#0b3d32] text-[#00261e] font-bold'
                  : 'bg-[#e2f9ef]/50 border-transparent text-[#404945] hover:bg-[#ddf3e9]'
              }`}
            >
              <div className="font-['Sora'] text-[10px] text-[#4a6700] uppercase font-bold">
                Part {idx + 1} ({chap.timestamp})
              </div>
              <div className="truncate font-['Manrope']">{chap.title}</div>
            </button>
          ))}
        </div>

        <div className="flex items-center justify-between text-[#404945] text-xs font-['Manrope'] pt-1">
          <span>Ward 12 Mumbai Live Test Dataset</span>
          <span className="font-['Sora'] font-bold text-[11px] bg-[#ddf3e9] px-2.5 py-1 rounded text-[#00261e]">
            Length: 02:14 · 1080p 60fps
          </span>
        </div>
      </div>
    </div>
  );
};

interface PilotModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PilotModal: React.FC<PilotModalProps> = ({ isOpen, onClose }) => {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    designation: 'Ward Officer / Sanitation Inspector',
    municipality: 'Brihanmumbai Municipal Corp (BMC)',
    wardName: 'Ward 12 (K/West)',
    email: '',
    phone: '',
    households: '25,000 - 50,000 households'
  });

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-[#00261e]/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in"
      onClick={onClose}
    >
      <div
        className="bg-[#ffffff] rounded-2xl max-w-xl w-full p-6 sm:p-8 flex flex-col gap-5 shadow-2xl relative border border-[#c0c8c4]/30"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#4a6700] text-[26px]">handshake</span>
            <h3 className="font-['Sora'] font-bold text-xl text-[#00261e]">
              Request Ward Pilot Sandbox
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#ddf3e9] flex items-center justify-center text-[#0c1f19] hover:bg-[#d7ede3]"
            type="button"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>

        {submitted ? (
          <div className="py-8 flex flex-col items-center text-center gap-4">
            <div className="w-16 h-16 rounded-full bg-[#ddf3e9] text-[#4a6700] flex items-center justify-center">
              <span className="material-symbols-outlined text-[36px]">verified</span>
            </div>
            <h4 className="font-['Sora'] font-bold text-lg text-[#00261e]">
              Sandbox Credentials Dispatched
            </h4>
            <p className="font-['Manrope'] text-sm text-[#404945] max-w-md">
              We have provisioned the trial API endpoints and mock weighbridge telemetry keys for{' '}
              <strong>{formData.wardName}</strong>. Our municipal solutions engineer will contact you shortly.
            </p>
            <button
              onClick={onClose}
              className="mt-2 bg-[#00261e] text-[#c5f26a] px-6 py-2.5 rounded-xl font-bold font-['Manrope'] text-sm"
            >
              Back to App
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <p className="font-['Manrope'] text-xs sm:text-sm text-[#404945]">
              Deploy Clean-Loop in your administrative circle in 14 days with zero disruptions to active waste vehicle vendors.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-[#00261e] mb-1 font-['Manrope']">
                  Your Full Name
                </label>
                <input
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. Anand Kadam"
                  className="w-full bg-[#e8fef4] border border-[#c0c8c4]/40 rounded-xl px-3 py-2 text-sm text-[#0c1f19] focus:outline-none focus:border-[#0b3d32]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#00261e] mb-1 font-['Manrope']">
                  Designation / Role
                </label>
                <select
                  value={formData.designation}
                  onChange={(e) => setFormData({ ...formData, designation: e.target.value })}
                  className="w-full bg-[#e8fef4] border border-[#c0c8c4]/40 rounded-xl px-3 py-2 text-sm text-[#0c1f19] focus:outline-none"
                >
                  <option>Ward Officer / Sanitary Inspector</option>
                  <option>Municipal Executive Engineer (SWM)</option>
                  <option>Waste Collection Fleet Contractor</option>
                  <option>Resident Welfare Association Leader</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-[#00261e] mb-1 font-['Manrope']">
                  Urban Local Body / Municipality
                </label>
                <input
                  required
                  value={formData.municipality}
                  onChange={(e) => setFormData({ ...formData, municipality: e.target.value })}
                  placeholder="e.g. BMC Mumbai"
                  className="w-full bg-[#e8fef4] border border-[#c0c8c4]/40 rounded-xl px-3 py-2 text-sm text-[#0c1f19] focus:outline-none focus:border-[#0b3d32]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#00261e] mb-1 font-['Manrope']">
                  Pilot Ward & Cluster
                </label>
                <input
                  required
                  value={formData.wardName}
                  onChange={(e) => setFormData({ ...formData, wardName: e.target.value })}
                  placeholder="e.g. Ward 12 (K/West)"
                  className="w-full bg-[#e8fef4] border border-[#c0c8c4]/40 rounded-xl px-3 py-2 text-sm text-[#0c1f19] focus:outline-none focus:border-[#0b3d32]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-[#00261e] mb-1 font-['Manrope']">
                  Official Email Address
                </label>
                <input
                  required
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="name@mcgm.gov.in"
                  className="w-full bg-[#e8fef4] border border-[#c0c8c4]/40 rounded-xl px-3 py-2 text-sm text-[#0c1f19] focus:outline-none focus:border-[#0b3d32]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#00261e] mb-1 font-['Manrope']">
                  Contact Phone / WhatsApp
                </label>
                <input
                  required
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="+91 98200 XXXXX"
                  className="w-full bg-[#e8fef4] border border-[#c0c8c4]/40 rounded-xl px-3 py-2 text-sm text-[#0c1f19] focus:outline-none focus:border-[#0b3d32]"
                />
              </div>
            </div>

            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl font-semibold text-sm text-[#404945] hover:bg-[#ddf3e9]"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-[#0b3d32] hover:bg-[#00261e] text-[#c5f26a] px-6 py-2.5 rounded-xl font-bold font-['Manrope'] text-sm shadow-md transition-all"
              >
                Submit Pilot Application
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

interface PointsToastProps {
  pointsEarned: number;
  message: string;
  onClose: () => void;
}

export const PointsToast: React.FC<PointsToastProps> = ({ pointsEarned, message, onClose }) => {
  return (
    <div className="fixed bottom-6 right-6 z-50 bg-[#00261e] text-white p-4 rounded-2xl shadow-2xl flex items-center gap-3 border border-[#c5f26a]/40 max-w-sm animate-in slide-in-from-bottom-5">
      <div className="w-10 h-10 rounded-xl bg-[#c5f26a] text-[#00261e] flex items-center justify-center font-['Sora'] font-extrabold text-base">
        +{pointsEarned}
      </div>
      <div className="flex flex-col flex-1">
        <span className="font-['Sora'] text-xs font-bold text-[#c5f26a]">
          CIVIC REWARD RECORDED
        </span>
        <span className="font-['Manrope'] text-xs text-white/90">{message}</span>
      </div>
      <button onClick={onClose} className="text-white/60 hover:text-white">
        <span className="material-symbols-outlined text-[18px]">close</span>
      </button>
    </div>
  );
};
