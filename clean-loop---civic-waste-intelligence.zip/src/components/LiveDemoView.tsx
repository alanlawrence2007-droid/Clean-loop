import React, { useState } from 'react';
import { WASTE_RULES_DATABASE } from '../data/wasteDatabase';

interface LiveDemoViewProps {
  onAwardPoints: (pts: number, reason: string) => void;
  onOpenPilotModal: () => void;
}

export const LiveDemoView: React.FC<LiveDemoViewProps> = ({ onAwardPoints, onOpenPilotModal }) => {
  const [activeStep, setActiveStep] = useState<number>(1);
  const [selectedDemoItem, setSelectedDemoItem] = useState<string>('milk');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  const item = WASTE_RULES_DATABASE[selectedDemoItem] || WASTE_RULES_DATABASE.milk;

  const handleNextStep = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      if (activeStep < 4) {
        setActiveStep(activeStep + 1);
        if (activeStep === 1) {
          onAwardPoints(10, 'Demo: Verified segregation of packaging');
        }
      } else {
        setActiveStep(1);
      }
    }, 400);
  };

  return (
    <div className="w-full min-h-[calc(100vh-80px)] bg-[#e8fef4] py-8 px-4 md:px-8 lg:px-12 flex flex-col gap-6">
      <div className="max-w-7xl mx-auto w-full flex flex-col gap-8">
        {/* Header */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-[#c0c8c4]/30 flex flex-col gap-3">
          <div className="inline-flex items-center gap-2 bg-[#d7ede3] px-3 py-1 rounded-full w-max">
            <span className="material-symbols-outlined text-[16px] text-[#00261e]">sports_score</span>
            <span className="font-['Sora'] text-[11px] font-bold text-[#00261e] uppercase tracking-wider">
              End-to-End Simulation
            </span>
          </div>
          <h2 className="font-['Sora'] text-2xl sm:text-3xl font-bold text-[#00261e]">
            Live Circularity Loop Demonstration
          </h2>
          <p className="font-['Manrope'] text-sm text-[#404945] max-w-3xl">
            Experience how a single citizen action at their kitchen counter ripples through vehicle dispatch and weighbridge settlement in under 4 steps.
          </p>
        </div>

        {/* Step Progress Tracker */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { num: 1, title: 'Citizen Edge Scan', desc: 'Item vision check' },
            { num: 2, title: 'Bin Segregation', desc: 'Prep & clean drop' },
            { num: 3, title: 'Fleet Routing', desc: 'Dynamic pickup ETA' },
            { num: 4, title: 'Weighbridge Audit', desc: 'Cryptographic receipt' }
          ].map((st) => (
            <div
              key={st.num}
              onClick={() => setActiveStep(st.num)}
              className={`p-4 rounded-2xl cursor-pointer transition-all border flex flex-col gap-1 ${
                activeStep === st.num
                  ? 'bg-[#0b3d32] text-white border-[#0b3d32] shadow-md'
                  : 'bg-white text-[#0c1f19] border-[#c0c8c4]/30 hover:bg-[#e2f9ef]'
              }`}
            >
              <div className="flex items-center justify-between">
                <span
                  className={`w-6 h-6 rounded-full flex items-center justify-center font-['Sora'] text-xs font-bold ${
                    activeStep === st.num ? 'bg-[#c5f26a] text-[#00261e]' : 'bg-[#d7ede3] text-[#00261e]'
                  }`}
                >
                  {st.num}
                </span>
                <span className="text-[10px] uppercase font-bold opacity-70">Step {st.num}</span>
              </div>
              <strong className="font-['Sora'] text-sm mt-1">{st.title}</strong>
              <span className="text-[11px] opacity-80 font-['Manrope']">{st.desc}</span>
            </div>
          ))}
        </div>

        {/* Step Interactive Canvas */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-md border border-[#c0c8c4]/30 flex flex-col gap-6">
          {activeStep === 1 && (
            <div className="flex flex-col gap-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h3 className="font-['Sora'] text-xl font-bold text-[#00261e]">
                    Step 1: Point Optical Viewfinder at Waste Material
                  </h3>
                  <p className="font-['Manrope'] text-xs text-[#404945]">
                    Select an item below to see the edge classifier output confidence score.
                  </p>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setSelectedDemoItem('milk')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold ${
                      selectedDemoItem === 'milk' ? 'bg-[#0b3d32] text-[#c5f26a]' : 'bg-[#e2f9ef]'
                    }`}
                  >
                    🥛 Milk Pouch
                  </button>
                  <button
                    onClick={() => setSelectedDemoItem('coconut')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold ${
                      selectedDemoItem === 'coconut' ? 'bg-[#0b3d32] text-[#c5f26a]' : 'bg-[#e2f9ef]'
                    }`}
                  >
                    🥥 Coconut Husk
                  </button>
                  <button
                    onClick={() => setSelectedDemoItem('battery')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold ${
                      selectedDemoItem === 'battery' ? 'bg-[#0b3d32] text-[#c5f26a]' : 'bg-[#e2f9ef]'
                    }`}
                  >
                    🔋 AA Battery
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                <div className="relative w-full h-56 bg-[#00261e] rounded-2xl overflow-hidden flex flex-col justify-between p-4 text-white">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-[#c5f26a] font-['Sora'] font-bold">LIVE CAMERA STREAM</span>
                    <span>Ward 12 (K/West)</span>
                  </div>
                  <div className="self-center my-auto flex flex-col items-center">
                    <span className="text-4xl">{item.icon}</span>
                    <span className="mt-2 text-xs font-['Sora'] font-bold bg-black/70 px-3 py-1 rounded text-[#c5f26a]">
                      {item.title}
                    </span>
                  </div>
                  <div className="flex justify-between text-xs text-white/80">
                    <span>{item.confidence}</span>
                    <span>Rule: {item.citation.split(':')[0]}</span>
                  </div>
                </div>

                <div className="flex flex-col gap-3">
                  <div className="bg-[#e2f9ef] p-4 rounded-2xl flex flex-col gap-2">
                    <span className="text-xs font-bold text-[#00261e] font-['Sora']">
                      Target Destination:
                    </span>
                    <div className="flex items-center gap-2 text-sm font-bold text-[#00261e]">
                      <span className="material-symbols-outlined text-[20px]">{item.binIcon}</span>
                      <span>{item.binName}</span>
                    </div>
                    <span className="text-xs text-[#404945] font-['Manrope']">{item.desc}</span>
                  </div>

                  <button
                    onClick={handleNextStep}
                    disabled={isProcessing}
                    className="w-full bg-[#0b3d32] text-[#c5f26a] hover:bg-[#00261e] py-3.5 rounded-xl font-bold font-['Manrope'] text-sm transition-all"
                  >
                    {isProcessing ? 'Processing...' : 'Proceed to Step 2: Bin Prep & Drop →'}
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeStep === 2 && (
            <div className="flex flex-col gap-6">
              <h3 className="font-['Sora'] text-xl font-bold text-[#00261e]">
                Step 2: Follow Preparation Directive & Confirm Segregation
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                <div className="bg-[#e2f9ef] p-6 rounded-2xl flex flex-col gap-3">
                  <span className="font-['Sora'] text-xs font-bold text-[#00261e] uppercase">
                    Preparation Checklist
                  </span>
                  <ul className="flex flex-col gap-2 text-xs font-['Manrope'] text-[#0c1f19]">
                    {item.steps.map((st, i) => (
                      <li key={i} className="flex items-center gap-2">
                        <span className="material-symbols-outlined text-[18px] text-[#4a6700]">
                          check_circle
                        </span>
                        <span>{st}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="flex flex-col gap-4">
                  <div className="bg-white border border-[#c0c8c4]/40 p-4 rounded-2xl flex items-center justify-between">
                    <div>
                      <div className="font-['Sora'] text-sm font-bold text-[#00261e]">
                        Citizen Civic Reward
                      </div>
                      <div className="font-['Manrope'] text-xs text-[#404945]">
                        Awarded upon verified QR bin scan
                      </div>
                    </div>
                    <span className="font-['Sora'] font-extrabold text-xl text-[#4a6700]">+10 Pts</span>
                  </div>

                  <button
                    onClick={handleNextStep}
                    disabled={isProcessing}
                    className="w-full bg-[#0b3d32] text-[#c5f26a] hover:bg-[#00261e] py-3.5 rounded-xl font-bold font-['Manrope'] text-sm transition-all"
                  >
                    {isProcessing ? 'Verifying...' : 'Confirm Segregation & Route Compactor →'}
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeStep === 3 && (
            <div className="flex flex-col gap-6">
              <h3 className="font-['Sora'] text-xl font-bold text-[#00261e]">
                Step 3: Compactor Vehicle Optimization & Live Lane Telemetry
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                <div className="bg-[#00261e] p-6 rounded-2xl text-white flex flex-col gap-4">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-[#c5f26a] font-['Sora'] font-bold">
                      TRUCK #MH-02-CW-4412
                    </span>
                    <span className="bg-black/60 px-2 py-0.5 rounded text-[10px]">ETA: 6 MINS</span>
                  </div>
                  <div className="font-['Manrope'] text-xs text-white/80">
                    Lane 4A pickup scheduled. Citizen confirmation logged to ward compactor route queue.
                  </div>
                  <div className="w-full bg-white/20 h-2 rounded-full overflow-hidden">
                    <div className="bg-[#c5f26a] h-full w-[75%]"></div>
                  </div>
                </div>

                <div className="flex flex-col gap-4">
                  <div className="bg-[#e2f9ef] p-4 rounded-2xl text-xs font-['Manrope'] text-[#00261e]">
                    <strong>GPS Honesty Active:</strong> Actual vehicle satellite pings received every 10 seconds. No simulated or faked arrival estimates.
                  </div>

                  <button
                    onClick={handleNextStep}
                    disabled={isProcessing}
                    className="w-full bg-[#0b3d32] text-[#c5f26a] hover:bg-[#00261e] py-3.5 rounded-xl font-bold font-['Manrope'] text-sm transition-all"
                  >
                    {isProcessing ? 'Routing...' : 'Simulate Weighbridge Delivery →'}
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeStep === 4 && (
            <div className="flex flex-col gap-6">
              <h3 className="font-['Sora'] text-xl font-bold text-[#00261e]">
                Step 4: Weighbridge Optical Purity Scan & Municipal Ledger Stamp
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                <div className="bg-[#f5fdf9] border border-[#c0c8c4]/40 p-6 rounded-2xl flex flex-col gap-3 font-mono text-xs">
                  <div className="font-['Sora'] font-bold text-sm text-[#00261e] border-b pb-2">
                    WEIGHBRIDGE RECEIPT #MRF-3-2025-88
                  </div>
                  <div className="flex justify-between">
                    <span>Gross Truck Weight:</span>
                    <strong>14.28 Tonnes</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Tare (Empty) Weight:</span>
                    <strong>6.12 Tonnes</strong>
                  </div>
                  <div className="flex justify-between text-[#4a6700] font-bold">
                    <span>Optical Purity Index:</span>
                    <span>94.2% (Tier A Compost Grade)</span>
                  </div>
                  <div className="flex flex-col gap-1 pt-2 border-t text-[10px] text-[#404945]">
                    <span>Cryptographic Ledger Hash:</span>
                    <span className="text-[#0b3d32] break-all">
                      SHA256: 4f1a98c0b2d3e412...92b5
                    </span>
                  </div>
                </div>

                <div className="flex flex-col gap-4">
                  <div className="bg-[#e2f9ef] p-4 rounded-2xl text-xs font-['Manrope'] text-[#00261e]">
                    Full circular journey completed! Contamination avoided, contractor SLA verified, and civic points awarded.
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => setActiveStep(1)}
                      className="flex-1 bg-[#ddf3e9] text-[#00261e] py-3 rounded-xl font-bold font-['Manrope'] text-xs"
                    >
                      Restart Simulation
                    </button>
                    <button
                      onClick={onOpenPilotModal}
                      className="flex-1 bg-[#0b3d32] text-[#c5f26a] py-3 rounded-xl font-bold font-['Manrope'] text-xs shadow"
                    >
                      Deploy in Ward
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
