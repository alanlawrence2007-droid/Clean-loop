import React, { useState } from 'react';

export const DataHonestyView: React.FC = () => {
  const [selectedProofHash, setSelectedProofHash] = useState<string>(
    '7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069'
  );
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [verificationResult, setVerificationResult] = useState<boolean | null>(true);
  const [simulationMode, setSimulationMode] = useState<'clean_loop' | 'legacy'>('clean_loop');

  const handleVerify = () => {
    setIsVerifying(true);
    setVerificationResult(null);
    setTimeout(() => {
      setIsVerifying(false);
      setVerificationResult(true);
    }, 600);
  };

  return (
    <div className="w-full min-h-[calc(100vh-80px)] bg-[#e8fef4] py-8 px-4 md:px-8 lg:px-12 flex flex-col gap-6">
      <div className="max-w-7xl mx-auto w-full flex flex-col gap-8">
        {/* Header Block */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-[#c0c8c4]/30 flex flex-col gap-4">
          <div className="inline-flex items-center gap-2 bg-[#d7ede3] px-3 py-1 rounded-full w-max">
            <span className="material-symbols-outlined text-[16px] text-[#00261e]">gavel</span>
            <span className="font-['Sora'] text-[11px] font-bold text-[#00261e] uppercase tracking-wider">
              The Transparency Charter
            </span>
          </div>

          <h2 className="font-['Sora'] text-2xl sm:text-3xl font-bold text-[#00261e] tracking-tight">
            The Clean-Loop Data Honesty Protocol
          </h2>

          <p className="font-['Manrope'] text-sm sm:text-base text-[#404945] max-w-3xl leading-relaxed">
            Municipal waste dashboards routinely claim 95%+ segregation and 100% on-time routes while citizens look out the window at overflowing bins. Clean-Loop solves this with four non-negotiable architectural constraints enforced at hardware scale.
          </p>
        </div>

        {/* INTERACTIVE COMPARISON: Ghost Fleet vs Clean-Loop Raw Pings */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-[#c0c8c4]/30 flex flex-col gap-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="font-['Sora'] text-xs font-bold text-[#4a6700] uppercase">
                RULE 02 EXPERIMENT
              </span>
              <h3 className="font-['Sora'] text-xl font-bold text-[#00261e] mt-0.5">
                Ghost-Fleet Telemetry Simulator
              </h3>
              <p className="font-['Manrope'] text-xs text-[#404945]">
                Toggle between legacy simulated interpolation and Clean-Loop raw satellite verification.
              </p>
            </div>

            <div className="flex items-center bg-[#e2f9ef] p-1 rounded-xl border border-[#c0c8c4]/30">
              <button
                onClick={() => setSimulationMode('clean_loop')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold font-['Manrope'] transition-all ${
                  simulationMode === 'clean_loop'
                    ? 'bg-[#0b3d32] text-[#c5f26a] shadow-sm'
                    : 'text-[#404945]'
                }`}
              >
                Clean-Loop Raw Ping (Honest)
              </button>
              <button
                onClick={() => setSimulationMode('legacy')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold font-['Manrope'] transition-all ${
                  simulationMode === 'legacy'
                    ? 'bg-[#ba1a1a] text-white shadow-sm'
                    : 'text-[#404945]'
                }`}
              >
                Legacy Falsified Interpolation
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
            <div className="w-full h-48 bg-[#00261e] rounded-2xl p-4 flex flex-col justify-between text-white relative overflow-hidden">
              <div className="flex justify-between items-center text-xs">
                <span className="font-mono text-[#c5f26a]">Vehicle: #MH-02-CW-1904</span>
                <span className="font-['Sora'] text-[10px] bg-black/60 px-2 py-0.5 rounded">
                  {simulationMode === 'clean_loop' ? 'STALL DETECTED' : 'FAKED MOTION'}
                </span>
              </div>

              {simulationMode === 'clean_loop' ? (
                <div className="flex flex-col items-center gap-2 my-auto">
                  <div className="w-10 h-10 rounded-full bg-[#ffdad6] text-[#ba1a1a] flex items-center justify-center">
                    <span className="material-symbols-outlined text-[24px]">signal_cellular_off</span>
                  </div>
                  <span className="text-xs font-['Sora'] font-bold text-center text-[#ffdad6]">
                    GPS Dropped in Underpass 9m ago — Movement Display Frozen
                  </span>
                  <span className="text-[11px] font-['Manrope'] text-white/70">
                    No artificial ping interpolation allowed. Contractor cannot bill stalled time.
                  </span>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-2 my-auto">
                  <div className="w-10 h-10 rounded-full bg-[#c5f26a]/30 text-[#c5f26a] flex items-center justify-center animate-spin">
                    <span className="material-symbols-outlined text-[24px]">sync</span>
                  </div>
                  <span className="text-xs font-['Sora'] font-bold text-center text-yellow-300">
                    Legacy Simulation: Inventing smooth movements along route
                  </span>
                  <span className="text-[11px] font-['Manrope'] text-white/70">
                    Truck is physically parked, but dashboard displays "On Schedule".
                  </span>
                </div>
              )}

              <div className="flex justify-between text-[11px] text-[#e0f6ec]">
                <span>Status: {simulationMode === 'clean_loop' ? 'Honest Signal Loss' : 'Falsified Ghost Fleet'}</span>
                <span>Audit Risk: {simulationMode === 'clean_loop' ? '0%' : 'High / Fraud Alert'}</span>
              </div>
            </div>

            <div className="flex flex-col gap-3 text-xs font-['Manrope'] text-[#404945] leading-relaxed">
              <h4 className="font-['Sora'] font-bold text-sm text-[#00261e]">
                Why Traditional GPS Dashboards Lie:
              </h4>
              <p>
                Fleet contractors are penalized for route delays, leading legacy software vendors to implement <em>linear spline interpolation</em>. When GPS hardware drops offline, the software computes an imaginary truck moving at 20 km/h along the planned road.
              </p>
              <p>
                <strong>The Clean-Loop Hardware Standard:</strong> Every satellite ping must be signed by the onboard telematics unit with a monotonic clock counter. Missing pings render as explicit halts on the municipal map.
              </p>
            </div>
          </div>
        </div>

        {/* CRYPTOGRAPHIC AUDIT PROOF VERIFIER */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-[#c0c8c4]/30 flex flex-col gap-6">
          <div>
            <span className="font-['Sora'] text-xs font-bold text-[#4a6700] uppercase">
              RULE 04 LEDGER
            </span>
            <h3 className="font-['Sora'] text-xl font-bold text-[#00261e] mt-0.5">
              SHA-256 Civic Ledger Proof Verifier
            </h3>
            <p className="font-['Manrope'] text-xs text-[#404945]">
              Verify that an individual citizen grievance or weighbridge measurement has not been altered in the municipal database.
            </p>
          </div>

          <div className="flex flex-col gap-3">
            <label className="text-xs font-bold text-[#00261e] font-['Manrope']">
              Public Ledger Hash / Docket Proof
            </label>
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                value={selectedProofHash}
                onChange={(e) => setSelectedProofHash(e.target.value)}
                placeholder="Enter 64-character SHA-256 hash..."
                className="flex-1 bg-[#e8fef4] border border-[#c0c8c4]/40 rounded-xl px-4 py-2.5 font-mono text-xs text-[#0c1f19] focus:outline-none focus:border-[#0b3d32]"
              />
              <button
                onClick={handleVerify}
                disabled={isVerifying}
                className="bg-[#0b3d32] hover:bg-[#00261e] text-[#c5f26a] px-6 py-2.5 rounded-xl font-bold text-xs font-['Manrope'] shadow-sm transition-all"
              >
                {isVerifying ? 'Verifying...' : 'Verify Cryptographic Proof'}
              </button>
            </div>
          </div>

          {verificationResult && (
            <div className="bg-[#e2f9ef] p-5 rounded-2xl border border-[#0b3d32]/20 flex flex-col gap-3">
              <div className="flex items-center gap-2 text-[#4a6700]">
                <span className="material-symbols-outlined text-[20px]">verified</span>
                <span className="font-['Sora'] text-xs font-bold">
                  VALID CIVIC PROOF CONFIRMED ON LEDGER
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs font-['Manrope']">
                <div className="bg-white p-3 rounded-xl border border-[#c0c8c4]/30">
                  <span className="text-[#404945] block mb-1">Citizen Photo Hash:</span>
                  <strong className="font-mono text-[10px] break-all">e3b0c442...98b5</strong>
                </div>
                <div className="bg-white p-3 rounded-xl border border-[#c0c8c4]/30">
                  <span className="text-[#404945] block mb-1">Weighbridge Ticket:</span>
                  <strong className="text-[#00261e]">MRF-3 #49102-GH</strong>
                </div>
                <div className="bg-white p-3 rounded-xl border border-[#c0c8c4]/30">
                  <span className="text-[#404945] block mb-1">Dual-Party Close:</span>
                  <strong className="text-[#4a6700]">Citizen Confirmed (10:14 IST)</strong>
                </div>
                <div className="bg-white p-3 rounded-xl border border-[#c0c8c4]/30">
                  <span className="text-[#404945] block mb-1">Municipal Docket:</span>
                  <strong className="text-[#00261e]">BMC/MSW/2025/K-W/90412</strong>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* 4 RULES DEEP-DIVE SUMMARY */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-[#c0c8c4]/30 flex flex-col gap-3">
            <span className="font-['Sora'] text-[10px] font-bold text-[#4a6700] uppercase">RULE 01</span>
            <h4 className="font-['Sora'] text-lg font-bold text-[#00261e]">
              Confidence Bounds on Vision Inference
            </h4>
            <p className="font-['Manrope'] text-xs text-[#404945] leading-relaxed">
              Whenever Clean-Loop's edge model identifies packaging (e.g. an LDPE milk pouch vs PVC blister foil), it renders an explicit confidence floor (e.g. 96%). If the score is below 80%, the citizen is prompted for manual clarification rather than risking bulk batch cross-contamination.
            </p>
          </div>

          <div className="bg-white rounded-3xl p-6 shadow-sm border border-[#c0c8c4]/30 flex flex-col gap-3">
            <span className="font-['Sora'] text-[10px] font-bold text-[#4a6700] uppercase">RULE 03</span>
            <h4 className="font-['Sora'] text-lg font-bold text-[#00261e]">
              Unilateral Close Prohibition
            </h4>
            <p className="font-['Manrope'] text-xs text-[#404945] leading-relaxed">
              No contractor or junior sanitary inspector can set a grievance state to 'Resolved' on their own. Once work is reported complete, a 48-hour window opens for the citizen who reported it to upload a verifying clearance photo.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
