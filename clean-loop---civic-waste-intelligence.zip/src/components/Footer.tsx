import React from 'react';
import { ActiveTab } from '../types';

interface FooterProps {
  setActiveTab: (tab: ActiveTab) => void;
  onOpenPilotModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({ setActiveTab, onOpenPilotModal }) => {
  return (
    <footer className="w-full bg-[#e2f9ef] text-[#0c1f19] py-16 border-t border-[#c0c8c4]/30">
      <div className="w-full max-w-7xl mx-auto px-6 md:px-8 lg:px-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 mb-12">
          {/* Brand info */}
          <div className="lg:col-span-2 flex flex-col gap-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#0b3d32] flex items-center justify-center text-[#c5f26a]">
                <span className="material-symbols-outlined text-[20px]">autorenew</span>
              </div>
              <span className="font-['Sora'] font-semibold text-lg text-[#00261e]">Clean-Loop</span>
            </div>
            <p className="font-['Manrope'] text-sm text-[#404945] max-w-sm leading-relaxed">
              Real-time civic waste dispatch, automated contamination auditing, and verified municipal circularity ledger across metropolitan clusters.
            </p>
            <div className="flex items-center gap-3 mt-1">
              <div className="inline-flex items-center gap-2 bg-[#d1e8de] px-3 py-1.5 rounded-full border border-[#c0c8c4]/40">
                <span className="w-2 h-2 rounded-full bg-[#4a6700] animate-pulse"></span>
                <span className="font-['Sora'] text-[11px] font-bold text-[#00261e] tracking-wider uppercase">
                  Telemetry Stream Active
                </span>
              </div>
            </div>
          </div>

          {/* Infrastructure */}
          <div className="flex flex-col gap-3">
            <span className="font-['Sora'] font-semibold text-base text-[#00261e] mb-1">
              Infrastructure
            </span>
            <button
              onClick={() => setActiveTab('platform')}
              className="font-['Manrope'] text-sm text-[#404945] hover:text-[#0c1f19] text-left transition-colors"
            >
              Platform Core
            </button>
            <button
              onClick={() => setActiveTab('municipalities')}
              className="font-['Manrope'] text-sm text-[#404945] hover:text-[#0c1f19] text-left transition-colors"
            >
              Municipal Routing
            </button>
            <button
              onClick={() => setActiveTab('citizen-app')}
              className="font-['Manrope'] text-sm text-[#404945] hover:text-[#0c1f19] text-left transition-colors"
            >
              Citizen Sensor App
            </button>
            <button
              onClick={() => setActiveTab('live-demo')}
              className="font-['Manrope'] text-sm text-[#404945] hover:text-[#0c1f19] text-left transition-colors"
            >
              Live Spatial Telemetry
            </button>
          </div>

          {/* Accountability */}
          <div className="flex flex-col gap-3">
            <span className="font-['Sora'] font-semibold text-base text-[#00261e] mb-1">
              Accountability
            </span>
            <button
              onClick={() => setActiveTab('data-honesty')}
              className="font-['Manrope'] text-sm text-[#404945] hover:text-[#0c1f19] text-left transition-colors"
            >
              Data Honesty Standard
            </button>
            <button
              onClick={() => setActiveTab('municipalities')}
              className="font-['Manrope'] text-sm text-[#404945] hover:text-[#0c1f19] text-left transition-colors"
            >
              Weighbridge Verification
            </button>
            <button
              onClick={() => setActiveTab('data-honesty')}
              className="font-['Manrope'] text-sm text-[#404945] hover:text-[#0c1f19] text-left transition-colors"
            >
              AI Estimation Bounds
            </button>
            <button
              onClick={() => setActiveTab('data-honesty')}
              className="font-['Manrope'] text-sm text-[#404945] hover:text-[#0c1f19] text-left transition-colors"
            >
              Municipal Audit Trails
            </button>
          </div>

          {/* Engagement */}
          <div className="flex flex-col gap-3">
            <span className="font-['Sora'] font-semibold text-base text-[#00261e] mb-1">
              Engagement
            </span>
            <button
              onClick={onOpenPilotModal}
              className="font-['Manrope'] text-sm text-[#404945] hover:text-[#0c1f19] text-left transition-colors"
            >
              Partner with Us
            </button>
            <button
              onClick={onOpenPilotModal}
              className="font-['Manrope'] text-sm text-[#404945] hover:text-[#0c1f19] text-left transition-colors"
            >
              Ward Pilot Sandbox
            </button>
            <button
              onClick={() => setActiveTab('data-honesty')}
              className="font-['Manrope'] text-sm text-[#404945] hover:text-[#0c1f19] text-left transition-colors"
            >
              Open GeoJSON APIs
            </button>
            <button
              onClick={onOpenPilotModal}
              className="font-['Manrope'] text-sm text-[#404945] hover:text-[#0c1f19] text-left transition-colors"
            >
              Contact Dispatch Support
            </button>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-[#c0c8c4]/30 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex flex-col sm:flex-row items-center gap-3 sm:gap-4 text-center sm:text-left">
            <span className="font-['Manrope'] text-xs text-[#404945]">
              © 2025 Clean-Loop Technologies Inc. Municipal Solid Waste Intelligence.
            </span>
            <span className="font-['Sora'] text-[11px] font-bold text-[#404945] bg-[#d7ede3] px-2.5 py-1 rounded-md">
              Municipal Solid Waste Intelligence v2.4
            </span>
          </div>
          <div className="flex items-center gap-6">
            <span className="font-['Manrope'] text-xs text-[#404945] hover:text-[#0c1f19] cursor-pointer">
              Privacy Framework
            </span>
            <span className="font-['Manrope'] text-xs text-[#404945] hover:text-[#0c1f19] cursor-pointer">
              Terms of Service
            </span>
            <span className="font-['Manrope'] text-xs text-[#404945] hover:text-[#0c1f19] cursor-pointer">
              Civic Ledger Registry
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
