import React, { useState, useRef, useEffect } from 'react';
import { WasteItemRule, WasteStreamType } from '../types';
import { WASTE_RULES_DATABASE } from '../data/wasteDatabase';

interface CitizenAppViewProps {
  citizenPoints: number;
  onAwardPoints: (pts: number, reason: string) => void;
  onOpenPilotModal: () => void;
}

export const CitizenAppView: React.FC<CitizenAppViewProps> = ({
  citizenPoints,
  onAwardPoints,
  onOpenPilotModal,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'scanner' | 'streams' | 'report' | 'rewards'>('scanner');
  const [selectedPreset, setSelectedPreset] = useState<string>('milk');
  const [customPhotoUrl, setCustomPhotoUrl] = useState<string | null>(null);
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Scanner state
  const [isScanning, setIsScanning] = useState(false);
  const [analyzedItem, setAnalyzedItem] = useState<WasteItemRule>(WASTE_RULES_DATABASE.milk);
  const [confirmedItems, setConfirmedItems] = useState<string[]>([]);

  // 6 Streams directory state
  const [selectedStreamFilter, setSelectedStreamFilter] = useState<WasteStreamType | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Grievance report state
  const [reportForm, setReportForm] = useState({
    location: 'Seven Bungalows Metro Station, Andheri West',
    category: 'Overflowing Community Bin',
    description: 'Bin overflowing onto pedestrian sidewalk for past 18 hours. Waste is scattered by strays.',
    gpsCoords: '19.1290° N, 72.8258° E (Ward 12)',
    photoUrl: 'https://images.unsplash.com/photo-1605600659908-0ef719419d41?w=600&auto=format&fit=crop&q=80'
  });
  const [submittedReport, setSubmittedReport] = useState<{
    hash: string;
    docket: string;
    timestamp: string;
  } | null>(null);

  // Start live webcam if user requests
  useEffect(() => {
    let stream: MediaStream | null = null;
    if (isCameraActive && videoRef.current) {
      navigator.mediaDevices
        ?.getUserMedia({ video: { facingMode: 'environment' } })
        .then((s) => {
          stream = s;
          if (videoRef.current) {
            videoRef.current.srcObject = s;
          }
          setCameraError(null);
        })
        .catch((err) => {
          console.warn('Camera access error:', err);
          setCameraError('Webcam access was denied or is not supported. Using high-fidelity preset simulation instead.');
          setIsCameraActive(false);
        });
    }

    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [isCameraActive]);

  const handleSelectPreset = (key: string) => {
    setSelectedPreset(key);
    setCustomPhotoUrl(null);
    setIsCameraActive(false);
    setIsScanning(true);
    setTimeout(() => {
      setAnalyzedItem(WASTE_RULES_DATABASE[key] || WASTE_RULES_DATABASE.milk);
      setIsScanning(false);
    }, 450);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setCustomPhotoUrl(url);
      setIsCameraActive(false);
      setIsScanning(true);
      setTimeout(() => {
        // Map based on file name or default to recyclable
        setAnalyzedItem(WASTE_RULES_DATABASE.milk);
        setIsScanning(false);
      }, 500);
    }
  };

  const handleConfirmSegregation = () => {
    if (!confirmedItems.includes(analyzedItem.id)) {
      setConfirmedItems([...confirmedItems, analyzedItem.id]);
      onAwardPoints(10, `Properly segregated ${analyzedItem.name} into ${analyzedItem.binName}`);
    }
  };

  const handleReportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const randomHash = 'SHA256: ' + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
    const randomDocket = 'BMC/MSW/2025/K-W/' + Math.floor(10000 + Math.random() * 90000);
    setSubmittedReport({
      hash: randomHash,
      docket: randomDocket,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' IST'
    });
    onAwardPoints(25, 'Filed geotagged civic grievance with dual-party verification stamp');
  };

  // Filter items for 6 Streams Directory
  const allItemsList = Object.values(WASTE_RULES_DATABASE);
  const filteredItems = allItemsList.filter((item) => {
    const matchesStream = selectedStreamFilter === 'all' || item.stream === selectedStreamFilter;
    const matchesQuery =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.desc.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStream && matchesQuery;
  });

  return (
    <div className="w-full min-h-[calc(100vh-80px)] bg-[#e8fef4] py-8 px-4 md:px-8 lg:px-12 flex flex-col gap-6">
      <div className="max-w-7xl mx-auto w-full flex flex-col gap-6">
        {/* Sub Navigation Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-3 rounded-2xl shadow-sm border border-[#c0c8c4]/30">
          <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
            <button
              onClick={() => setActiveSubTab('scanner')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold font-['Manrope'] transition-all ${
                activeSubTab === 'scanner'
                  ? 'bg-[#0b3d32] text-[#c5f26a] shadow-sm'
                  : 'text-[#404945] hover:bg-[#e2f9ef]'
              }`}
            >
              <span className="material-symbols-outlined text-[18px]">center_focus_strong</span>
              <span>Camera Classifier</span>
            </button>
            <button
              onClick={() => setActiveSubTab('streams')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold font-['Manrope'] transition-all ${
                activeSubTab === 'streams'
                  ? 'bg-[#0b3d32] text-[#c5f26a] shadow-sm'
                  : 'text-[#404945] hover:bg-[#e2f9ef]'
              }`}
            >
              <span className="material-symbols-outlined text-[18px]">recycling</span>
              <span>6-Stream Directory</span>
            </button>
            <button
              onClick={() => setActiveSubTab('report')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold font-['Manrope'] transition-all ${
                activeSubTab === 'report'
                  ? 'bg-[#0b3d32] text-[#c5f26a] shadow-sm'
                  : 'text-[#404945] hover:bg-[#e2f9ef]'
              }`}
            >
              <span className="material-symbols-outlined text-[18px]">report_problem</span>
              <span>Grievance Reporting</span>
            </button>
            <button
              onClick={() => setActiveSubTab('rewards')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold font-['Manrope'] transition-all ${
                activeSubTab === 'rewards'
                  ? 'bg-[#0b3d32] text-[#c5f26a] shadow-sm'
                  : 'text-[#404945] hover:bg-[#e2f9ef]'
              }`}
            >
              <span className="material-symbols-outlined text-[18px]">military_tech</span>
              <span>Civic Rewards</span>
            </button>
          </div>

          <div className="flex items-center gap-3 pr-2">
            <span className="font-['Sora'] text-xs text-[#00261e] font-bold">
              Ward 12 (K/West)
            </span>
            <span className="bg-[#c5f26a] text-[#4f6e00] text-xs font-bold px-3 py-1 rounded-full font-['Sora'] shadow-sm">
              {citizenPoints} Civic Pts
            </span>
          </div>
        </div>

        {/* SUBTAB 1: CAMERA CLASSIFIER */}
        {activeSubTab === 'scanner' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Viewfinder Column */}
            <div className="lg:col-span-6 flex flex-col gap-4">
              <div className="bg-white rounded-3xl p-4 sm:p-6 shadow-md border border-[#c0c8c4]/30 flex flex-col gap-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#4a6700] animate-pulse"></span>
                    <span className="font-['Sora'] text-xs font-bold text-[#00261e] uppercase">
                      Edge AI Viewfinder
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setIsCameraActive(!isCameraActive)}
                      className={`text-xs px-3 py-1 rounded-full font-semibold font-['Manrope'] transition-all flex items-center gap-1 ${
                        isCameraActive
                          ? 'bg-[#ba1a1a] text-white'
                          : 'bg-[#d7ede3] text-[#00261e] hover:bg-[#c9dfd5]'
                      }`}
                    >
                      <span className="material-symbols-outlined text-[14px]">
                        {isCameraActive ? 'videocam_off' : 'photo_camera'}
                      </span>
                      {isCameraActive ? 'Stop Webcam' : 'Use Live Camera'}
                    </button>
                  </div>
                </div>

                {cameraError && (
                  <div className="bg-[#ffdad6] text-[#93000a] text-xs p-2.5 rounded-xl flex items-center gap-2">
                    <span className="material-symbols-outlined text-[16px]">info</span>
                    <span>{cameraError}</span>
                  </div>
                )}

                {/* Viewport Frame */}
                <div className="relative w-full aspect-[4/3] rounded-2xl overflow-hidden bg-[#00261e] flex flex-col justify-between p-4 shadow-inner">
                  {isCameraActive ? (
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      muted
                      className="absolute inset-0 w-full h-full object-cover"
                    />
                  ) : customPhotoUrl ? (
                    <img
                      src={customPhotoUrl}
                      alt="Uploaded item"
                      className="absolute inset-0 w-full h-full object-cover"
                    />
                  ) : selectedPreset === 'milk' ? (
                    <img
                      src="https://lh3.googleusercontent.com/aida-public/AB6AXuBN1AFb2F4Ft-nnYm3t1aRUjIgMQqfPNeRuMth4bjlkcMnVbotsHtvZBlOmF6Y527bPsUIKYcdBoQv3Sv1cwEMmTfqtL5hhXZvp6lFgU-oQTSXpJpYFwg4tnApyxA0PT06fmD9UnK2UEtHt7PE80pee-Xcuu7G3tkDqYdv1gdjIyKxR0Tbv-BUBlimO3PJ5Gt6hxzqupvVrq3r-hU0CYCYZn2qdSTP1mbmvTJE8X9_lG9Ch4BNLOjUS_w"
                      alt="Milk pouch"
                      className="absolute inset-0 w-full h-full object-cover opacity-90"
                    />
                  ) : (
                    <div className="absolute inset-0 w-full h-full bg-[#0b3d32] flex items-center justify-center">
                      <span className="text-6xl">{analyzedItem.icon}</span>
                    </div>
                  )}

                  {/* Top HUD */}
                  <div className="relative z-10 flex items-center justify-between">
                    <span className="bg-[#e8fef4]/90 backdrop-blur-md px-3 py-1 rounded-full font-['Sora'] text-[11px] font-bold text-[#00261e] flex items-center gap-1.5 shadow-sm">
                      <span className="w-2 h-2 rounded-full bg-[#4a6700] animate-pulse"></span>
                      OPTICAL SENSOR ACTIVE
                    </span>
                    <span className="bg-black/60 backdrop-blur-md text-[#c5f26a] font-['Sora'] text-[11px] font-bold px-2.5 py-0.5 rounded">
                      60 FPS · LATENCY 240MS
                    </span>
                  </div>

                  {/* Target Scanner Reticle */}
                  <div className="relative z-10 self-center my-auto flex flex-col items-center">
                    <div
                      className={`w-36 h-36 border-2 border-dashed rounded-3xl flex items-center justify-center transition-all ${
                        isScanning
                          ? 'border-yellow-400 scale-105 animate-pulse bg-yellow-400/10'
                          : 'border-[#c5f26a] bg-black/20 backdrop-blur-[2px]'
                      }`}
                    >
                      <span className="font-['Sora'] text-[11px] font-bold bg-[#00261e]/90 text-[#c5f26a] px-3 py-1 rounded-md text-center shadow">
                        {isScanning ? 'SCANNING...' : `${analyzedItem.name.toUpperCase()} DETECTED`}
                      </span>
                    </div>
                  </div>

                  {/* Bottom HUD */}
                  <div className="relative z-10 flex items-center justify-between text-white text-xs">
                    <span className="font-['Sora'] font-bold text-[#c5f26a]">
                      {analyzedItem.confidence}
                    </span>
                    <span className="bg-black/50 px-2 py-0.5 rounded font-['Manrope'] text-[11px]">
                      Ward 12 Rule Engine v2.4
                    </span>
                  </div>
                </div>

                {/* Preset Item Selector Bar */}
                <div className="flex flex-col gap-2 pt-1">
                  <div className="flex items-center justify-between">
                    <span className="font-['Manrope'] text-xs font-bold text-[#00261e]">
                      Test Item Presets:
                    </span>
                    <label className="text-xs font-semibold text-[#0b3d32] hover:underline cursor-pointer flex items-center gap-1">
                      <span className="material-symbols-outlined text-[16px]">upload_file</span>
                      <span>Upload Custom Photo</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </label>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {[
                      { key: 'milk', label: '🥛 Milk Pouch' },
                      { key: 'coconut', label: '🥥 Coconut Husk' },
                      { key: 'blister', label: '💊 Blister Pack' },
                      { key: 'battery', label: '🔋 AA Battery' },
                      { key: 'pad', label: '🩹 Sanitary Pad' },
                      { key: 'styrofoam', label: '📦 Thermocol' },
                      { key: 'cable', label: '🔌 E-Waste Cable' }
                    ].map((item) => (
                      <button
                        key={item.key}
                        onClick={() => handleSelectPreset(item.key)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold font-['Manrope'] transition-all ${
                          selectedPreset === item.key && !customPhotoUrl
                            ? 'bg-[#0b3d32] text-[#c5f26a] font-bold shadow-sm'
                            : 'bg-[#e2f9ef] text-[#00261e] hover:bg-[#d7ede3]'
                        }`}
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Instruction & Compliance Details Column */}
            <div className="lg:col-span-6 flex flex-col gap-4">
              <div className="bg-white rounded-3xl p-6 shadow-md border border-[#c0c8c4]/30 flex flex-col gap-5">
                {/* Header status */}
                <div className="flex items-center justify-between">
                  <span
                    className="px-3.5 py-1 rounded-full text-white font-['Sora'] text-xs font-bold uppercase tracking-wider shadow-sm"
                    style={{ backgroundColor: analyzedItem.streamColor }}
                  >
                    {analyzedItem.streamBadge}
                  </span>
                  <span className="font-['Sora'] text-xs font-bold text-[#4a6700] bg-[#e2f9ef] px-3 py-1 rounded-full">
                    By-Law Verified
                  </span>
                </div>

                <div>
                  <h3 className="font-['Sora'] text-2xl font-bold text-[#00261e]">
                    {analyzedItem.title}
                  </h3>
                  <p className="font-['Manrope'] text-sm text-[#404945] mt-1 leading-relaxed">
                    {analyzedItem.desc}
                  </p>
                </div>

                {/* Target Bin Card */}
                <div className="bg-[#e2f9ef] p-4 rounded-2xl flex items-center justify-between border border-[#c0c8c4]/30">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-14 h-14 rounded-2xl flex items-center justify-center shadow-inner"
                      style={{ backgroundColor: analyzedItem.binBg, color: analyzedItem.binColor }}
                    >
                      <span className="material-symbols-outlined text-[32px]">
                        {analyzedItem.binIcon}
                      </span>
                    </div>
                    <div className="flex flex-col">
                      <span className="font-['Sora'] text-[10px] uppercase font-bold text-[#404945]">
                        Drop In Destination Bin
                      </span>
                      <span className="font-['Sora'] text-lg font-bold text-[#00261e]">
                        {analyzedItem.binName}
                      </span>
                      <span className="font-['Manrope'] text-xs text-[#00261e]">
                        Scheduled: <strong>{analyzedItem.collectionTime}</strong>
                      </span>
                    </div>
                  </div>
                </div>

                {/* Preparation steps */}
                <div className="bg-[#f5fdf9] p-4 rounded-2xl flex flex-col gap-2.5 border border-[#c0c8c4]/30">
                  <span className="font-['Sora'] text-xs font-bold text-[#00261e]">
                    Mandatory Preparation & Disposal Steps:
                  </span>
                  <ul className="flex flex-col gap-2 text-xs font-['Manrope'] text-[#0c1f19]">
                    {analyzedItem.steps.map((step, idx) => (
                      <li key={idx} className="flex items-start gap-2.5">
                        <span className="w-5 h-5 rounded-full bg-[#d7ede3] text-[#00261e] flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                          {idx + 1}
                        </span>
                        <span className="leading-relaxed">{step}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Citation */}
                <div className="flex flex-col gap-1 text-[#404945] text-xs font-['Manrope'] bg-[#e2f9ef]/60 p-3 rounded-xl border border-[#c0c8c4]/20">
                  <div className="flex items-center gap-1.5 font-bold text-[#00261e]">
                    <span className="material-symbols-outlined text-[16px]">gavel</span>
                    <span>Legal Reference:</span>
                  </div>
                  <div>{analyzedItem.citation}</div>
                  {analyzedItem.penaltyTier && (
                    <div className="text-[#ba1a1a] font-semibold mt-0.5">
                      Penalty for non-compliance: {analyzedItem.penaltyTier}
                    </div>
                  )}
                </div>

                {/* Confirmation Button */}
                <button
                  onClick={handleConfirmSegregation}
                  disabled={confirmedItems.includes(analyzedItem.id)}
                  className={`w-full py-4 rounded-xl font-['Manrope'] text-sm font-bold flex items-center justify-center gap-2 shadow-md transition-all active:scale-95 ${
                    confirmedItems.includes(analyzedItem.id)
                      ? 'bg-[#2E9E5B] text-white cursor-default'
                      : 'bg-[#0b3d32] text-[#c5f26a] hover:bg-[#00261e]'
                  }`}
                >
                  <span className="material-symbols-outlined text-[20px]">
                    {confirmedItems.includes(analyzedItem.id) ? 'task_alt' : 'verified_user'}
                  </span>
                  <span>
                    {confirmedItems.includes(analyzedItem.id)
                      ? 'Segregation Confirmed (+10 Pts Claimed)'
                      : 'Confirm Segregation & Claim +10 Civic Pts'}
                  </span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 2: 6-STREAM DIRECTORY */}
        {activeSubTab === 'streams' && (
          <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-md border border-[#c0c8c4]/30 flex flex-col gap-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h3 className="font-['Sora'] text-2xl font-bold text-[#00261e]">
                  Official 6-Stream Segregation Directory
                </h3>
                <p className="font-['Manrope'] text-sm text-[#404945] mt-1">
                  Unified protocol compliance matrix for Greater Mumbai Ward 12 solid waste by-laws.
                </p>
              </div>

              {/* Search bar */}
              <div className="relative min-w-[260px]">
                <span className="material-symbols-outlined absolute left-3 top-2.5 text-[#404945] text-[18px]">
                  search
                </span>
                <input
                  type="text"
                  placeholder="Filter items (e.g. coconut, plastic, battery)..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-[#e8fef4] rounded-xl border border-[#c0c8c4]/40 text-[#0c1f19] focus:outline-none focus:border-[#0b3d32]"
                />
              </div>
            </div>

            {/* Stream Filter Pills */}
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setSelectedStreamFilter('all')}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold font-['Manrope'] transition-all ${
                  selectedStreamFilter === 'all'
                    ? 'bg-[#00261e] text-[#c5f26a] font-bold'
                    : 'bg-[#e2f9ef] text-[#404945] hover:bg-[#d7ede3]'
                }`}
              >
                All Streams ({allItemsList.length})
              </button>
              <button
                onClick={() => setSelectedStreamFilter('wet')}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold font-['Manrope'] transition-all ${
                  selectedStreamFilter === 'wet'
                    ? 'bg-[#2E9E5B] text-white font-bold'
                    : 'bg-[#e2f9ef] text-[#2E9E5B] hover:bg-[#d7ede3]'
                }`}
              >
                Wet / Biodegradable
              </button>
              <button
                onClick={() => setSelectedStreamFilter('dry')}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold font-['Manrope'] transition-all ${
                  selectedStreamFilter === 'dry'
                    ? 'bg-[#2D6CDF] text-white font-bold'
                    : 'bg-[#e2f9ef] text-[#2D6CDF] hover:bg-[#d7ede3]'
                }`}
              >
                Dry Recyclables
              </button>
              <button
                onClick={() => setSelectedStreamFilter('hazardous')}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold font-['Manrope'] transition-all ${
                  selectedStreamFilter === 'hazardous'
                    ? 'bg-[#D9402F] text-white font-bold'
                    : 'bg-[#e2f9ef] text-[#D9402F] hover:bg-[#d7ede3]'
                }`}
              >
                Domestic Hazardous
              </button>
              <button
                onClick={() => setSelectedStreamFilter('sanitary')}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold font-['Manrope'] transition-all ${
                  selectedStreamFilter === 'sanitary'
                    ? 'bg-[#E08A00] text-white font-bold'
                    : 'bg-[#e2f9ef] text-[#E08A00] hover:bg-[#d7ede3]'
                }`}
              >
                Sanitary / Bio-Medical
              </button>
              <button
                onClick={() => setSelectedStreamFilter('ewaste')}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold font-['Manrope'] transition-all ${
                  selectedStreamFilter === 'ewaste'
                    ? 'bg-[#7B4FD6] text-white font-bold'
                    : 'bg-[#e2f9ef] text-[#7B4FD6] hover:bg-[#d7ede3]'
                }`}
              >
                E-Waste Electronics
              </button>
            </div>

            {/* Items Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredItems.map((item) => (
                <div
                  key={item.id}
                  className="bg-[#e8fef4] p-5 rounded-2xl flex flex-col justify-between gap-4 border border-[#c0c8c4]/30 hover:border-[#0b3d32] transition-colors"
                >
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center justify-between">
                      <span className="text-2xl">{item.icon}</span>
                      <span
                        className="px-2.5 py-0.5 rounded-full text-[10px] font-bold text-white uppercase font-['Sora']"
                        style={{ backgroundColor: item.streamColor }}
                      >
                        {item.stream.toUpperCase()}
                      </span>
                    </div>
                    <h4 className="font-['Sora'] text-base font-bold text-[#00261e]">{item.name}</h4>
                    <p className="font-['Manrope'] text-xs text-[#404945] leading-relaxed line-clamp-2">
                      {item.desc}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-[#c0c8c4]/30 flex items-center justify-between">
                    <div className="flex items-center gap-1 text-xs font-semibold text-[#00261e]">
                      <span className="material-symbols-outlined text-[16px]">{item.binIcon}</span>
                      <span>{item.binName}</span>
                    </div>
                    <button
                      onClick={() => {
                        setSelectedPreset(item.id);
                        setActiveSubTab('scanner');
                      }}
                      className="text-xs font-bold text-[#0b3d32] hover:underline"
                    >
                      Inspect →
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* SUBTAB 3: OFFLINE-FIRST GRIEVANCE REPORTING */}
        {activeSubTab === 'report' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-8 shadow-md border border-[#c0c8c4]/30 flex flex-col gap-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-['Sora'] text-2xl font-bold text-[#00261e]">
                    File Civic Waste Grievance
                  </h3>
                  <p className="font-['Manrope'] text-xs sm:text-sm text-[#404945] mt-1">
                    Rule 03 & 04 Compliant: Dual-party close requires citizen photo stamp before municipal payout.
                  </p>
                </div>
                <div className="hidden sm:inline-flex items-center gap-1.5 bg-[#d7ede3] px-3 py-1 rounded-full text-xs font-bold text-[#00261e]">
                  <span className="w-2 h-2 rounded-full bg-[#4a6700]"></span>
                  <span>IndexedDB Cached</span>
                </div>
              </div>

              {submittedReport ? (
                <div className="bg-[#e2f9ef] p-6 rounded-2xl flex flex-col gap-4 border border-[#0b3d32]/20">
                  <div className="flex items-center gap-3 text-[#4a6700]">
                    <span className="material-symbols-outlined text-[32px]">task_alt</span>
                    <div>
                      <h4 className="font-['Sora'] text-lg font-bold text-[#00261e]">
                        Grievance Docket Filed Successfully
                      </h4>
                      <span className="font-['Manrope'] text-xs text-[#404945]">
                        Logged to Municipal Waste Ledger at {submittedReport.timestamp}
                      </span>
                    </div>
                  </div>

                  <div className="bg-white p-4 rounded-xl flex flex-col gap-2 font-mono text-xs">
                    <div className="flex justify-between border-b border-[#c0c8c4]/30 pb-2">
                      <span className="text-[#404945]">Municipal Docket:</span>
                      <strong className="text-[#00261e]">{submittedReport.docket}</strong>
                    </div>
                    <div className="flex flex-col gap-1 pt-1">
                      <span className="text-[#404945]">SHA-256 Ledger Hash:</span>
                      <span className="text-[11px] text-[#0b3d32] break-all">
                        {submittedReport.hash}
                      </span>
                    </div>
                  </div>

                  <p className="font-['Manrope'] text-xs text-[#404945]">
                    A compactor crew has been dispatched. Once the contractor submits their cleanup photo, you will be notified on WhatsApp/SMS to approve or veto the resolution.
                  </p>

                  <button
                    onClick={() => setSubmittedReport(null)}
                    className="self-start bg-[#0b3d32] text-[#c5f26a] px-5 py-2 rounded-xl text-xs font-bold font-['Manrope'] mt-1"
                  >
                    File Another Report
                  </button>
                </div>
              ) : (
                <form onSubmit={handleReportSubmit} className="flex flex-col gap-4">
                  <div>
                    <label className="block text-xs font-bold text-[#00261e] mb-1 font-['Manrope']">
                      Grievance Category
                    </label>
                    <select
                      value={reportForm.category}
                      onChange={(e) => setReportForm({ ...reportForm, category: e.target.value })}
                      className="w-full bg-[#e8fef4] border border-[#c0c8c4]/40 rounded-xl px-3 py-2 text-xs sm:text-sm text-[#0c1f19] focus:outline-none focus:border-[#0b3d32]"
                    >
                      <option>Overflowing Community Bin</option>
                      <option>Uncollected Household Doorstep Waste</option>
                      <option>Illegal Construction Debris Dumping</option>
                      <option>Leachate Spillage from Municipal Truck</option>
                      <option>Mixed Waste Contamination at Dump Point</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#00261e] mb-1 font-['Manrope']">
                      Exact Landmark & Pavement Location
                    </label>
                    <input
                      required
                      value={reportForm.location}
                      onChange={(e) => setReportForm({ ...reportForm, location: e.target.value })}
                      className="w-full bg-[#e8fef4] border border-[#c0c8c4]/40 rounded-xl px-3 py-2 text-xs sm:text-sm text-[#0c1f19] focus:outline-none focus:border-[#0b3d32]"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-[#00261e] mb-1 font-['Manrope']">
                        Raw GPS Telemetry Tag
                      </label>
                      <input
                        readOnly
                        value={reportForm.gpsCoords}
                        className="w-full bg-[#ddf3e9] border border-[#c0c8c4]/40 rounded-xl px-3 py-2 text-xs text-[#00261e] font-mono cursor-not-allowed"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-[#00261e] mb-1 font-['Manrope']">
                        Network Offline Cache
                      </label>
                      <div className="w-full bg-[#ddf3e9] rounded-xl px-3 py-2 text-xs text-[#4a6700] font-semibold flex items-center gap-1.5">
                        <span className="material-symbols-outlined text-[16px]">wifi_protected_setup</span>
                        <span>0 Data Loss Guarantee</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#00261e] mb-1 font-['Manrope']">
                      Observation & Hazard Details
                    </label>
                    <textarea
                      rows={3}
                      value={reportForm.description}
                      onChange={(e) => setReportForm({ ...reportForm, description: e.target.value })}
                      className="w-full bg-[#e8fef4] border border-[#c0c8c4]/40 rounded-xl px-3 py-2 text-xs sm:text-sm text-[#0c1f19] focus:outline-none focus:border-[#0b3d32]"
                    />
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full bg-[#0b3d32] hover:bg-[#00261e] text-[#c5f26a] py-3.5 rounded-xl font-bold font-['Manrope'] text-sm shadow-md transition-all active:scale-95 flex items-center justify-center gap-2"
                    >
                      <span className="material-symbols-outlined text-[20px]">send</span>
                      <span>Dispatch Grievance to Ward 12 Matrix (+25 Pts)</span>
                    </button>
                  </div>
                </form>
              )}
            </div>

            {/* Right side helper info */}
            <div className="lg:col-span-5 flex flex-col gap-4">
              <div className="bg-white rounded-3xl p-6 shadow-md border border-[#c0c8c4]/30 flex flex-col gap-4">
                <div className="flex items-center gap-2 text-[#00261e]">
                  <span className="material-symbols-outlined text-[#4a6700] text-[22px]">how_to_reg</span>
                  <h4 className="font-['Sora'] font-bold text-base">The Citizen Veto Mechanism</h4>
                </div>
                <p className="font-['Manrope'] text-xs text-[#404945] leading-relaxed">
                  Under Clean-Loop's Rule 03 protocol, sanitation contractors are penalized if they report a grievance as 'Resolved' without an uploaded post-cleanup timestamped photo matching your original GPS locus.
                </p>
                <div className="bg-[#e2f9ef] p-3.5 rounded-xl flex items-center justify-between text-xs font-['Manrope'] text-[#00261e]">
                  <span>Citizen Verification Window</span>
                  <strong className="font-['Sora']">48 Hours</strong>
                </div>
                <div className="bg-[#e2f9ef] p-3.5 rounded-xl flex items-center justify-between text-xs font-['Manrope'] text-[#00261e]">
                  <span>Automatic Escalation</span>
                  <strong className="font-['Sora']">Municipal Commissioner SLA</strong>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 4: REWARDS & LEADERBOARD */}
        {activeSubTab === 'rewards' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div className="lg:col-span-6 bg-white rounded-3xl p-6 sm:p-8 shadow-md border border-[#c0c8c4]/30 flex flex-col gap-6">
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-['Sora'] text-xs font-bold text-[#404945] uppercase">
                    Your Civic Score
                  </span>
                  <h3 className="font-['Sora'] text-3xl font-extrabold text-[#00261e] mt-1">
                    {citizenPoints} Points
                  </h3>
                </div>
                <div className="w-14 h-14 rounded-2xl bg-[#c5f26a] text-[#00261e] flex items-center justify-center font-['Sora'] font-bold text-xl shadow">
                  ★ 3
                </div>
              </div>

              <div className="bg-[#e2f9ef] p-4 rounded-2xl flex flex-col gap-3">
                <div className="flex justify-between text-xs font-['Manrope']">
                  <span className="text-[#404945]">Next Tier: Civic Purity Champion</span>
                  <strong className="text-[#00261e]">300 / 500 Pts</strong>
                </div>
                <div className="w-full bg-[#c9dfd5] h-3 rounded-full overflow-hidden">
                  <div
                    className="bg-[#0b3d32] h-full transition-all duration-500"
                    style={{ width: `${Math.min(100, (citizenPoints / 300) * 100)}%` }}
                  ></div>
                </div>
              </div>

              {/* Badges Earned */}
              <div className="flex flex-col gap-3">
                <span className="font-['Sora'] text-xs font-bold text-[#00261e] uppercase">
                  Badges Earned in Ward 12
                </span>
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-[#f5fdf9] border border-[#c0c8c4]/30 p-3 rounded-2xl flex flex-col items-center text-center gap-1">
                    <span className="text-2xl">🌿</span>
                    <span className="font-['Sora'] text-xs font-bold text-[#00261e]">Wet Segregator</span>
                    <span className="font-['Manrope'] text-[10px] text-[#404945]">10 Clean Bins</span>
                  </div>
                  <div className="bg-[#f5fdf9] border border-[#c0c8c4]/30 p-3 rounded-2xl flex flex-col items-center text-center gap-1">
                    <span className="text-2xl">🥛</span>
                    <span className="font-['Sora'] text-xs font-bold text-[#00261e]">Dry MLP Star</span>
                    <span className="font-['Manrope'] text-[10px] text-[#404945]">Rinsed & Dried</span>
                  </div>
                  <div className="bg-[#f5fdf9] border border-[#c0c8c4]/30 p-3 rounded-2xl flex flex-col items-center text-center gap-1">
                    <span className="text-2xl">🛡️</span>
                    <span className="font-['Sora'] text-xs font-bold text-[#00261e]">Civic Auditor</span>
                    <span className="font-['Manrope'] text-[10px] text-[#404945]">Dual-Sign Veto</span>
                  </div>
                </div>
              </div>

              {/* Redeem simulator */}
              <div className="pt-2 flex flex-col gap-2">
                <span className="font-['Sora'] text-xs font-bold text-[#00261e]">
                  Available Municipal Rebates:
                </span>
                <div className="bg-[#ddf3e9] p-3 rounded-xl flex items-center justify-between text-xs">
                  <span>5% Property Tax Rebate Voucher (350 Pts)</span>
                  <button
                    onClick={() => alert('Voucher reserved! Code: BMC-PROP-2025-W12')}
                    className="bg-[#0b3d32] text-[#c5f26a] px-3 py-1 rounded-lg font-bold"
                  >
                    Redeem
                  </button>
                </div>
              </div>
            </div>

            {/* Neighborhood Leaderboard */}
            <div className="lg:col-span-6 bg-white rounded-3xl p-6 sm:p-8 shadow-md border border-[#c0c8c4]/30 flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <h4 className="font-['Sora'] font-bold text-lg text-[#00261e]">
                  Ward 12 Neighborhood Leaderboard
                </h4>
                <span className="font-['Sora'] text-xs text-[#4a6700] font-bold">October 2025</span>
              </div>
              <div className="flex flex-col gap-2">
                {[
                  { rank: 1, name: 'Pooja R. (JVPD Scheme)', pts: 480, badge: '🥇 Gold' },
                  { rank: 2, name: 'Sunil Mehta (Seven Bungalows)', pts: 420, badge: '🥈 Silver' },
                  { rank: 3, name: 'Kavita Nair (Versova Yari Rd)', pts: 390, badge: '🥉 Bronze' },
                  { rank: 14, name: 'You (Citizen Sensor)', pts: citizenPoints, badge: '⭐ Active' }
                ].map((user) => (
                  <div
                    key={user.rank}
                    className={`flex items-center justify-between p-3 rounded-xl text-xs font-['Manrope'] ${
                      user.rank === 14
                        ? 'bg-[#c5f26a]/30 border border-[#4a6700] font-bold'
                        : 'bg-[#e8fef4]'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="font-['Sora'] font-bold text-sm w-5">{user.rank}.</span>
                      <span>{user.name}</span>
                    </div>
                    <div className="flex items-center gap-3 font-['Sora']">
                      <span>{user.badge}</span>
                      <strong className="text-[#00261e]">{user.pts} pts</strong>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
