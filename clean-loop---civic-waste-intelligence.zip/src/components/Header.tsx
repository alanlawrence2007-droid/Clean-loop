import React from 'react';
import { ActiveTab, Language } from '../types';
import { TRANSLATIONS } from '../data/translations';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  onOpenPilotModal: () => void;
  citizenPoints: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  language,
  setLanguage,
  onOpenPilotModal,
  citizenPoints,
}) => {
  const t = TRANSLATIONS[language];

  return (
    <header className="fixed top-0 w-full z-50 bg-[#e8fef4]/90 backdrop-blur-xl shadow-[0_1px_8px_rgba(11,61,50,0.06)] border-b border-[#c0c8c4]/20">
      <div className="h-20 w-full px-4 md:px-8 lg:px-12 flex items-center justify-between gap-4">
        {/* Logo and Nav */}
        <div className="flex items-center gap-6">
          <button
            onClick={() => setActiveTab('platform')}
            className="flex items-center gap-3 text-left group focus:outline-none"
          >
            <div className="w-10 h-10 rounded-xl bg-[#0b3d32] flex items-center justify-center text-[#c5f26a] shadow-[0_2px_8px_rgba(11,61,50,0.2)] group-hover:scale-105 transition-transform">
              <span className="material-symbols-outlined text-[24px]">autorenew</span>
            </div>
            <div className="flex flex-col">
              <span className="font-['Sora'] font-semibold text-lg text-[#00261e] leading-tight tracking-tight">
                Clean-Loop
              </span>
              <span className="font-['Sora'] font-bold text-[11px] text-[#404945] uppercase tracking-wider">
                {t.brandSubtitle}
              </span>
            </div>
          </button>

          <nav className="hidden xl:flex items-center gap-2 lg:gap-3">
            <button
              onClick={() => setActiveTab('platform')}
              className={`font-['Manrope'] text-sm font-semibold px-3 py-1.5 rounded-lg transition-colors ${
                activeTab === 'platform'
                  ? 'text-[#00261e] font-bold bg-[#d7ede3]'
                  : 'text-[#404945] hover:text-[#0c1f19] hover:bg-[#ddf3e9]/60'
              }`}
            >
              {t.platform}
            </button>
            <button
              onClick={() => setActiveTab('citizen-app')}
              className={`font-['Manrope'] text-sm font-semibold px-3 py-1.5 rounded-lg transition-colors ${
                activeTab === 'citizen-app'
                  ? 'text-[#00261e] font-bold bg-[#d7ede3]'
                  : 'text-[#404945] hover:text-[#0c1f19] hover:bg-[#ddf3e9]/60'
              }`}
            >
              {t.citizenApp}
            </button>
            <button
              onClick={() => setActiveTab('municipalities')}
              className={`font-['Manrope'] text-sm font-semibold px-3 py-1.5 rounded-lg transition-colors ${
                activeTab === 'municipalities'
                  ? 'text-[#00261e] font-bold bg-[#d7ede3]'
                  : 'text-[#404945] hover:text-[#0c1f19] hover:bg-[#ddf3e9]/60'
              }`}
            >
              {t.municipalities}
            </button>
            <button
              onClick={() => setActiveTab('data-honesty')}
              className={`font-['Manrope'] text-sm font-semibold px-3 py-1.5 rounded-lg transition-colors ${
                activeTab === 'data-honesty'
                  ? 'text-[#00261e] font-bold bg-[#d7ede3]'
                  : 'text-[#404945] hover:text-[#0c1f19] hover:bg-[#ddf3e9]/60'
              }`}
            >
              {t.dataHonesty}
            </button>
            <button
              onClick={() => setActiveTab('live-demo')}
              className={`font-['Manrope'] text-sm font-semibold px-3 py-1.5 rounded-lg transition-colors ${
                activeTab === 'live-demo'
                  ? 'text-[#00261e] font-bold bg-[#d7ede3]'
                  : 'text-[#404945] hover:text-[#0c1f19] hover:bg-[#ddf3e9]/60'
              }`}
            >
              {t.liveDemo}
            </button>
          </nav>
        </div>

        {/* Right side items */}
        <div className="flex items-center gap-3">
          {/* Language Switcher */}
          <div className="hidden sm:flex items-center bg-[#d7ede3] p-1 rounded-full border border-[#c0c8c4]/30">
            <button
              onClick={() => setLanguage('en')}
              className={`px-3 py-1 rounded-full text-xs font-semibold font-['Manrope'] transition-all ${
                language === 'en'
                  ? 'bg-[#0b3d32] text-[#c5f26a] shadow-sm'
                  : 'text-[#404945] hover:text-[#0c1f19]'
              }`}
              type="button"
            >
              ENG
            </button>
            <button
              onClick={() => setLanguage('hi')}
              className={`px-3 py-1 rounded-full text-xs font-semibold font-['Manrope'] transition-all ${
                language === 'hi'
                  ? 'bg-[#0b3d32] text-[#c5f26a] shadow-sm'
                  : 'text-[#404945] hover:text-[#0c1f19]'
              }`}
              type="button"
            >
              हिं
            </button>
            <button
              onClick={() => setLanguage('mr')}
              className={`px-3 py-1 rounded-full text-xs font-semibold font-['Manrope'] transition-all ${
                language === 'mr'
                  ? 'bg-[#0b3d32] text-[#c5f26a] shadow-sm'
                  : 'text-[#404945] hover:text-[#0c1f19]'
              }`}
              type="button"
            >
              मरा
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenPilotModal}
              className="hidden md:inline-flex items-center justify-center font-['Manrope'] text-sm font-semibold text-[#00261e] hover:bg-[#d7ede3] px-3.5 py-2 rounded-xl transition-all"
              type="button"
            >
              {t.partnerWithUs}
            </button>
            <button
              onClick={() => setActiveTab('citizen-app')}
              className="inline-flex items-center justify-center font-['Manrope'] text-sm font-bold bg-[#c5f26a] text-[#4f6e00] hover:bg-[#aad551] px-4 py-2 rounded-xl transition-all shadow-[0_2px_12px_rgba(197,242,106,0.35)] active:scale-95"
              type="button"
            >
              {t.launchApp}
            </button>
          </div>

          {/* User profile with points */}
          <div
            title={`Citizen Points: ${citizenPoints} (Ward 12 Purity Level 3)`}
            onClick={() => setActiveTab('citizen-app')}
            className="flex items-center gap-1.5 cursor-pointer bg-[#d7ede3] hover:bg-[#d1e8de] pl-1.5 pr-2.5 py-1 rounded-full transition-colors"
          >
            <div className="w-7 h-7 rounded-full bg-[#00261e] flex items-center justify-center text-white">
              <span className="material-symbols-outlined text-[16px]">person</span>
            </div>
            <span className="text-xs font-bold text-[#00261e] font-['Sora'] hidden sm:inline">
              {citizenPoints} pts
            </span>
          </div>
        </div>
      </div>

      {/* Mobile subnavigation bar for small screens */}
      <div className="xl:hidden flex items-center justify-around border-t border-[#c0c8c4]/20 bg-[#ddf3e9]/60 px-2 py-2 overflow-x-auto text-xs">
        <button
          onClick={() => setActiveTab('platform')}
          className={`px-3 py-1 rounded-lg font-semibold whitespace-nowrap ${
            activeTab === 'platform' ? 'bg-[#00261e] text-[#c5f26a]' : 'text-[#404945]'
          }`}
        >
          {t.platform}
        </button>
        <button
          onClick={() => setActiveTab('citizen-app')}
          className={`px-3 py-1 rounded-lg font-semibold whitespace-nowrap ${
            activeTab === 'citizen-app' ? 'bg-[#00261e] text-[#c5f26a]' : 'text-[#404945]'
          }`}
        >
          {t.citizenApp}
        </button>
        <button
          onClick={() => setActiveTab('municipalities')}
          className={`px-3 py-1 rounded-lg font-semibold whitespace-nowrap ${
            activeTab === 'municipalities' ? 'bg-[#00261e] text-[#c5f26a]' : 'text-[#404945]'
          }`}
        >
          {t.municipalities}
        </button>
        <button
          onClick={() => setActiveTab('data-honesty')}
          className={`px-3 py-1 rounded-lg font-semibold whitespace-nowrap ${
            activeTab === 'data-honesty' ? 'bg-[#00261e] text-[#c5f26a]' : 'text-[#404945]'
          }`}
        >
          {t.dataHonesty}
        </button>
        <button
          onClick={() => setActiveTab('live-demo')}
          className={`px-3 py-1 rounded-lg font-semibold whitespace-nowrap ${
            activeTab === 'live-demo' ? 'bg-[#00261e] text-[#c5f26a]' : 'text-[#404945]'
          }`}
        >
          {t.liveDemo}
        </button>
      </div>
    </header>
  );
};
