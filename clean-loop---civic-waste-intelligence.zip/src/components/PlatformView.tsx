import React, { useState } from 'react';
import { ActiveTab, Language, WasteItemRule } from '../types';
import { TRANSLATIONS } from '../data/translations';
import { WASTE_RULES_DATABASE } from '../data/wasteDatabase';

interface PlatformViewProps {
  setActiveTab: (tab: ActiveTab) => void;
  language: Language;
  onOpenDemoModal: () => void;
  onOpenPilotModal: () => void;
  onAwardPoints: (pts: number, reason: string) => void;
}

export const PlatformView: React.FC<PlatformViewProps> = ({
  setActiveTab,
  language,
  onOpenDemoModal,
  onOpenPilotModal,
  onAwardPoints,
}) => {
  const t = TRANSLATIONS[language];
  const [selectedRuleKey, setSelectedRuleKey] = useState<string>('coconut');
  const [isSegregationConfirmed, setIsSegregationConfirmed] = useState(false);
  const [customSearchQuery, setCustomSearchQuery] = useState('');

  const activeRule: WasteItemRule = WASTE_RULES_DATABASE[selectedRuleKey] || WASTE_RULES_DATABASE.coconut;

  const handleConfirmHeroSegregation = () => {
    setIsSegregationConfirmed(true);
    onAwardPoints(10, 'Verified dry recyclable milk pouch segregation in Ward 12');
    setTimeout(() => setIsSegregationConfirmed(false), 4000);
  };

  const handleSearchItem = (e: React.FormEvent) => {
    e.preventDefault();
    const query = customSearchQuery.toLowerCase().trim();
    if (!query) return;

    const matchedKey = Object.keys(WASTE_RULES_DATABASE).find((key) => {
      const item = WASTE_RULES_DATABASE[key];
      return (
        item.name.toLowerCase().includes(query) ||
        item.title.toLowerCase().includes(query) ||
        (item.hindiName && item.hindiName.toLowerCase().includes(query)) ||
        (item.marathiName && item.marathiName.toLowerCase().includes(query))
      );
    });

    if (matchedKey) {
      setSelectedRuleKey(matchedKey);
      setCustomSearchQuery('');
    } else {
      // Default to live classifier in Citizen app
      setActiveTab('citizen-app');
    }
  };

  return (
    <div className="flex flex-col w-full">
      {/* SECTION 1: HERO */}
      <section className="relative w-full px-4 md:px-8 lg:px-12 pt-8 pb-16 overflow-hidden bg-[#e8fef4]">
        {/* Ambient illumination */}
        <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-[#c5f26a]/30 blur-3xl pointer-events-none"></div>
        <div className="absolute top-1/2 -left-20 w-80 h-80 rounded-full bg-[#d7ede3]/60 blur-3xl pointer-events-none"></div>

        <div className="max-w-7xl mx-auto flex flex-col gap-10 relative z-10">
          {/* Tagline & Headline Block */}
          <div className="flex flex-col items-center md:items-start text-center md:text-left gap-4 max-w-4xl">
            <div className="inline-flex items-center gap-2 bg-[#d7ede3] px-4 py-1.5 rounded-full shadow-sm">
              <span className="w-2.5 h-2.5 rounded-full bg-[#4a6700] animate-pulse"></span>
              <span className="font-['Sora'] text-[11px] font-bold text-[#00261e] tracking-wider uppercase">
                {t.heroBadge}
              </span>
            </div>

            <h1 className="font-['Sora'] text-3xl sm:text-4xl md:text-5xl lg:text-[48px] text-[#00261e] tracking-tight font-extrabold max-w-3xl leading-tight">
              {t.heroTitlePrefix} <br className="hidden sm:inline" />
              Govern with{' '}
              <span className="bg-gradient-to-r from-[#00261e] to-[#10503f] bg-clip-text text-transparent">
                honest data.
              </span>
            </h1>

            <p className="font-['Manrope'] text-base md:text-lg text-[#404945] max-w-2xl leading-relaxed">
              {t.heroDesc}
            </p>

            {/* CTA Cluster */}
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 pt-2">
              <button
                onClick={() => setActiveTab('citizen-app')}
                className="inline-flex items-center gap-2 bg-[#c5f26a] text-[#4f6e00] hover:bg-[#aad551] px-7 py-3.5 rounded-xl font-['Manrope'] text-sm font-bold shadow-md transition-all active:scale-95"
                type="button"
              >
                <span className="material-symbols-outlined text-[20px]">qr_code_scanner</span>
                {t.launchWebApp}
              </button>

              <button
                onClick={() => setActiveTab('municipalities')}
                className="inline-flex items-center gap-2 bg-[#0b3d32] text-white hover:bg-[#003e2f] px-6 py-3.5 rounded-xl font-['Manrope'] text-sm font-semibold shadow-sm transition-all"
                type="button"
              >
                <span className="material-symbols-outlined text-[20px]">monitoring</span>
                {t.exploreMunicipal}
              </button>

              <button
                onClick={onOpenDemoModal}
                className="inline-flex items-center gap-1.5 bg-[#d7ede3] text-[#00261e] hover:bg-[#d1e8de] px-5 py-3.5 rounded-xl font-['Manrope'] text-sm font-semibold transition-all"
                type="button"
              >
                <span className="material-symbols-outlined text-[20px]">play_circle</span>
                {t.watchDemo}
              </button>
            </div>

            {/* System Status Micro-bar */}
            <div className="flex flex-wrap items-center gap-x-6 gap-y-2 pt-2 text-[#404945] font-['Manrope'] text-xs sm:text-sm">
              <div className="flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[#4a6700] text-[16px]">verified</span>
                <span>{t.activeDispatch}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[#00261e] text-[16px]">speed</span>
                <span>{t.p95Latency}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[#00261e] text-[16px]">lock</span>
                <span>{t.zeroGhost}</span>
              </div>
            </div>
          </div>

          {/* DUAL DEVICE HERO SHOWCASE */}
          <div className="w-full grid grid-cols-1 lg:grid-cols-12 gap-6 items-end pt-2">
            {/* Citizen Mobile Mockup (390px class preview) */}
            <div className="lg:col-span-5 flex justify-center lg:justify-end">
              <div className="w-full max-w-[390px] bg-white rounded-[28px] p-4 shadow-xl shadow-[#0b3d32]/10 flex flex-col gap-3 border border-[#c0c8c4]/30">
                {/* Mobile Screen Header */}
                <div className="flex items-center justify-between bg-[#e2f9ef] px-3 py-2 rounded-xl">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[#4a6700]"></span>
                    <span className="font-['Sora'] text-[11px] font-bold text-[#00261e]">
                      WARD 12 (K/WEST)
                    </span>
                  </div>
                  <span className="font-['Manrope'] text-xs bg-white px-2 py-0.5 rounded-md text-[#0c1f19] font-semibold">
                    GPS Locked
                  </span>
                </div>

                {/* Camera Scan Viewport */}
                <div className="relative w-full h-56 rounded-2xl overflow-hidden bg-[#0b3d32] flex flex-col justify-between p-3">
                  <img
                    className="absolute inset-0 w-full h-full object-cover opacity-85"
                    alt="Smartphone scanning milk pouch"
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuBN1AFb2F4Ft-nnYm3t1aRUjIgMQqfPNeRuMth4bjlkcMnVbotsHtvZBlOmF6Y527bPsUIKYcdBoQv3Sv1cwEMmTfqtL5hhXZvp6lFgU-oQTSXpJpYFwg4tnApyxA0PT06fmD9UnK2UEtHt7PE80pee-Xcuu7G3tkDqYdv1gdjIyKxR0Tbv-BUBlimO3PJ5Gt6hxzqupvVrq3r-hU0CYCYZn2qdSTP1mbmvTJE8X9_lG9Ch4BNLOjUS_w"
                  />
                  <div className="relative z-10 flex items-center justify-between">
                    <span className="bg-[#e8fef4]/90 backdrop-blur-md px-2.5 py-1 rounded-full font-['Sora'] text-[10px] font-bold text-[#00261e] flex items-center gap-1 shadow-sm">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#4a6700]"></span>
                      {t.opticalSensorActive}
                    </span>
                    <span className="bg-[#00261e]/80 backdrop-blur-md text-white font-['Sora'] text-[10px] font-bold px-2 py-0.5 rounded">
                      60 FPS
                    </span>
                  </div>

                  {/* Reticle Corner Markers */}
                  <div className="relative z-10 self-center my-auto flex flex-col items-center">
                    <div className="w-28 h-28 border-2 border-dashed border-[#c5f26a] rounded-2xl flex items-center justify-center bg-black/10 backdrop-blur-[2px]">
                      <span className="font-['Sora'] text-[10px] font-bold bg-[#00261e]/90 text-[#c5f26a] px-2 py-0.5 rounded text-center">
                        MILK POUCH DETECTED
                      </span>
                    </div>
                  </div>

                  <div className="relative z-10 flex items-center justify-between text-white">
                    <span className="font-['Sora'] text-[10px] font-bold text-[#c5f26a]">
                      [AI ESTIMATE · 96% CONF]
                    </span>
                    <button
                      onClick={() => setActiveTab('citizen-app')}
                      className="font-['Sora'] text-[10px] opacity-90 hover:opacity-100 underline"
                    >
                      Tap to Retake
                    </button>
                  </div>
                </div>

                {/* Instant Guidance Result Pill */}
                <div className="bg-[#d7ede3] rounded-xl p-3 flex flex-col gap-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-3 h-3 rounded-full bg-[#2D6CDF]"></span>
                      <span className="font-['Sora'] text-sm sm:text-base font-semibold text-[#00261e]">
                        Dry Recyclable (MLP)
                      </span>
                    </div>
                    <span className="font-['Sora'] text-[10px] font-bold bg-white text-[#00261e] px-2 py-0.5 rounded">
                      Rule 4B-Mumbai
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 text-[#404945] font-['Manrope'] text-xs">
                    <span className="material-symbols-outlined text-[16px] text-[#00261e]">water_drop</span>
                    <span>Rinse clean & dry before blue bin disposal. Cut corner left intact.</span>
                  </div>
                </div>

                {/* Resident Action Button */}
                <button
                  onClick={handleConfirmHeroSegregation}
                  className={`w-full py-3 rounded-xl font-['Manrope'] text-sm font-bold flex items-center justify-center gap-2 transition-all ${
                    isSegregationConfirmed
                      ? 'bg-[#2E9E5B] text-white'
                      : 'bg-[#0b3d32] text-[#c5f26a] hover:bg-[#003e2f] active:scale-95'
                  }`}
                  type="button"
                >
                  <span className="material-symbols-outlined text-[18px]">
                    {isSegregationConfirmed ? 'task_alt' : 'verified_user'}
                  </span>
                  {isSegregationConfirmed
                    ? 'Segregation Verified! (+10 Pts)'
                    : t.confirmSegregation}
                </button>
              </div>
            </div>

            {/* Municipal Command Overview Card */}
            <div className="lg:col-span-7 flex flex-col gap-4">
              <div className="bg-white rounded-2xl p-6 shadow-xl shadow-[#0b3d32]/10 flex flex-col gap-5 border border-[#c0c8c4]/30">
                {/* Command Console Header */}
                <div className="flex flex-wrap items-center justify-between gap-3 pb-2 bg-[#e2f9ef] px-4 py-3 rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-[#0b3d32] flex items-center justify-center text-[#c5f26a]">
                      <span className="material-symbols-outlined text-[18px]">hub</span>
                    </div>
                    <div>
                      <div className="font-['Sora'] text-base font-semibold text-[#00261e]">
                        Central MSW Command Matrix
                      </div>
                      <div className="font-['Manrope'] text-xs text-[#404945]">
                        Metropolitan Ward Hub · Cluster South-04
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="bg-[#d1e8de] px-2.5 py-1 rounded-full font-['Sora'] text-[10px] font-bold text-[#00261e] flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-[#4a6700] animate-pulse"></span>
                      TELEMETRY VERIFIED
                    </span>
                  </div>
                </div>

                {/* Hero Metrics Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="bg-[#e2f9ef] p-3.5 rounded-xl flex flex-col gap-1">
                    <div className="font-['Sora'] text-[11px] text-[#404945] font-bold uppercase">
                      Ward Segregation Rate
                    </div>
                    <div className="font-['Sora'] text-2xl font-bold text-[#00261e] flex items-baseline gap-1">
                      81.2%
                      <span className="text-[#4a6700] text-xs font-semibold font-['Manrope']">+4.8%</span>
                    </div>
                    <div className="font-['Manrope'] text-xs text-[#404945]">
                      Verified by Weighbridge MRF-3
                    </div>
                  </div>

                  <div className="bg-[#e2f9ef] p-3.5 rounded-xl flex flex-col gap-1">
                    <div className="font-['Sora'] text-[11px] text-[#404945] font-bold uppercase">
                      Ghost-Fleet Audit
                    </div>
                    <div className="font-['Sora'] text-2xl font-bold text-[#00261e]">0 Fake GPS</div>
                    <div className="font-['Manrope'] text-xs text-[#4a6700] font-semibold">
                      100% Raw Satellite Pings
                    </div>
                  </div>

                  <div className="bg-[#e2f9ef] p-3.5 rounded-xl flex flex-col gap-1">
                    <div className="font-['Sora'] text-[11px] text-[#404945] font-bold uppercase">
                      Citizen Confirmation
                    </div>
                    <div className="font-['Sora'] text-2xl font-bold text-[#00261e]">94.6%</div>
                    <div className="font-['Manrope'] text-xs text-[#404945]">
                      Dual-sign ticket close rate
                    </div>
                  </div>
                </div>

                {/* Mini Live Dispatch Topology Simulation */}
                <div className="bg-[#ddf3e9] p-4 rounded-xl flex flex-col gap-3">
                  <div className="flex items-center justify-between text-[#0c1f19]">
                    <span className="font-['Manrope'] text-sm font-semibold text-[#00261e] flex items-center gap-2">
                      <span className="material-symbols-outlined text-[18px] text-[#4a6700]">alt_route</span>
                      Live Route Cluster: Sector 9 Compactor #MH-02-CW-4412
                    </span>
                    <span className="font-['Sora'] text-[10px] font-bold bg-[#d7ede3] px-2 py-0.5 rounded text-[#00261e]">
                      On Schedule (6m ETA)
                    </span>
                  </div>

                  {/* Route Progression Bar */}
                  <div className="w-full bg-[#d1e8de] h-3 rounded-full overflow-hidden flex">
                    <div className="bg-[#00261e] h-full w-[65%]" title="Cleared Pickups"></div>
                    <div className="bg-[#c5f26a] h-full w-[15%] animate-pulse" title="Active Lane"></div>
                    <div className="bg-[#c9dfd5] h-full w-[20%]" title="Pending Pickups"></div>
                  </div>

                  <div className="flex items-center justify-between text-[#404945] font-['Manrope'] text-xs">
                    <span>Lane 4A (Wet Stream Audit: 92% purity)</span>
                    <button
                      onClick={() => setActiveTab('municipalities')}
                      className="text-[#00261e] font-semibold hover:underline"
                    >
                      Next Weighbridge Check: Hub Ghatkopar 14:30 IST →
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 2: CIVIC TRUST STRIP */}
      <section className="w-full bg-[#e2f9ef] py-6 px-4 md:px-8 lg:px-12 border-y border-[#c0c8c4]/30">
        <div className="max-w-7xl mx-auto flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <span className="font-['Sora'] text-[11px] font-bold text-[#404945] uppercase tracking-widest">
              {t.standardsTitle}
            </span>
            <span className="font-['Sora'] text-[11px] font-bold bg-[#d7ede3] text-[#00261e] px-3 py-1 rounded-full">
              Standard v2.4 Compliant
            </span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
            <div className="bg-white p-3.5 rounded-xl shadow-sm flex items-center gap-3 border border-[#c0c8c4]/20">
              <span className="material-symbols-outlined text-[#00261e] text-[24px]">policy</span>
              <div className="flex flex-col">
                <span className="font-['Manrope'] text-xs font-bold text-[#00261e]">Swachh Bharat</span>
                <span className="font-['Manrope'] text-[11px] text-[#404945]">Urban Protocol 2.0</span>
              </div>
            </div>

            <div className="bg-white p-3.5 rounded-xl shadow-sm flex items-center gap-3 border border-[#c0c8c4]/20">
              <span className="material-symbols-outlined text-[#00261e] text-[24px]">location_city</span>
              <div className="flex flex-col">
                <span className="font-['Manrope'] text-xs font-bold text-[#00261e]">BMC Ward 12 Pilot</span>
                <span className="font-['Manrope'] text-[11px] text-[#404945]">Greater Mumbai Corp</span>
              </div>
            </div>

            <div className="bg-white p-3.5 rounded-xl shadow-sm flex items-center gap-3 border border-[#c0c8c4]/20">
              <span className="material-symbols-outlined text-[#00261e] text-[24px]">schema</span>
              <div className="flex flex-col">
                <span className="font-['Manrope'] text-xs font-bold text-[#00261e]">Zod-Strict APIs</span>
                <span className="font-['Manrope'] text-[11px] text-[#404945]">Open Civic Waste Schema</span>
              </div>
            </div>

            <div className="bg-white p-3.5 rounded-xl shadow-sm flex items-center gap-3 border border-[#c0c8c4]/20">
              <span className="material-symbols-outlined text-[#00261e] text-[24px]">workspace_premium</span>
              <div className="flex flex-col">
                <span className="font-['Manrope'] text-xs font-bold text-[#00261e]">ISO 14001 Audited</span>
                <span className="font-['Manrope'] text-[11px] text-[#404945]">Chain-of-Custody Standard</span>
              </div>
            </div>

            <div className="bg-white p-3.5 rounded-xl shadow-sm flex items-center gap-3 col-span-2 md:col-span-1 border border-[#c0c8c4]/20">
              <span className="material-symbols-outlined text-[#4a6700] text-[24px]">verified</span>
              <div className="flex flex-col">
                <span className="font-['Manrope'] text-xs font-bold text-[#00261e]">100% Data Honesty</span>
                <span className="font-['Manrope'] text-[11px] text-[#404945]">No Ghost Fleets Guaranteed</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 3: THE DATA HONESTY PROTOCOL */}
      <section className="w-full bg-[#e8fef4] px-4 md:px-8 lg:px-12 py-16">
        <div className="max-w-7xl mx-auto flex flex-col gap-12">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="max-w-2xl flex flex-col gap-3">
              <div className="inline-flex items-center gap-2 bg-[#d1e8de] px-3 py-1 rounded-full w-max">
                <span className="material-symbols-outlined text-[16px] text-[#00261e]">gavel</span>
                <span className="font-['Sora'] text-[11px] font-bold text-[#00261e] uppercase tracking-wider">
                  {t.transparencyCharter}
                </span>
              </div>
              <h2 className="font-['Sora'] text-2xl sm:text-3xl font-semibold text-[#00261e] tracking-tight">
                {t.protocolTitle}
              </h2>
              <p className="font-['Manrope'] text-base text-[#404945]">
                Civic technology fails when dashboard vanity metrics replace ground reality. We built Clean-Loop around four non-negotiable honesty rules enforced by code, not promises.
              </p>
            </div>
            <div className="bg-[#0b3d32] text-white p-4 rounded-xl flex items-center gap-3 max-w-sm shadow-md">
              <span className="material-symbols-outlined text-[#c5f26a] text-[28px]">shield</span>
              <p className="font-['Manrope'] text-xs leading-snug">
                Telemetry is cryptographically signed at hardware scale with immutable audit logs.
              </p>
            </div>
          </div>

          {/* 4 Cardinal Rules Bento Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Rule 1 */}
            <div className="bg-white rounded-2xl p-6 shadow-sm flex flex-col justify-between gap-6 border border-[#c0c8c4]/30">
              <div className="flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <span className="font-['Sora'] text-[10px] font-bold bg-[#ddf3e9] text-[#00261e] px-2.5 py-1 rounded">
                    RULE 01
                  </span>
                  <span className="font-['Sora'] text-[10px] font-bold text-[#404945]">
                    [AI ESTIMATE · BOUNDED]
                  </span>
                </div>
                <h3 className="font-['Sora'] text-xl font-semibold text-[#00261e]">
                  "AI Estimate, Not Absolute Truth"
                </h3>
                <p className="font-['Manrope'] text-sm text-[#404945] leading-relaxed">
                  Every vision classifier outputs an explicit confidence score and the exact local ward by-law citation. We never present algorithmic guesses as legal compliance mandates.
                </p>
              </div>
              <div className="bg-[#e2f9ef] p-3.5 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#4a6700] text-[20px]">psychology</span>
                  <span className="font-['Manrope'] text-xs text-[#00261e] font-bold">Optical Model v4.1</span>
                </div>
                <span className="font-['Manrope'] text-xs bg-white px-2 py-1 rounded text-[#404945] font-semibold">
                  Confidence Floor: 82%
                </span>
              </div>
            </div>

            {/* Rule 2 */}
            <div className="bg-white rounded-2xl p-6 shadow-sm flex flex-col justify-between gap-6 border border-[#c0c8c4]/30">
              <div className="flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <span className="font-['Sora'] text-[10px] font-bold bg-[#ddf3e9] text-[#00261e] px-2.5 py-1 rounded">
                    RULE 02
                  </span>
                  <span className="font-['Sora'] text-[10px] font-bold text-[#4a6700]">
                    ANTI-GHOST FLEET
                  </span>
                </div>
                <h3 className="font-['Sora'] text-xl font-semibold text-[#00261e]">
                  "No Fake GPS Movements"
                </h3>
                <p className="font-['Manrope'] text-sm text-[#404945] leading-relaxed">
                  We cleanly distinguish between an official route schedule, a historical pattern estimate, and an actual live satellite ping. If a truck loses signal, we display signal loss, never simulated movement.
                </p>
              </div>
              <div className="bg-[#e2f9ef] p-3.5 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#00261e] text-[20px]">satellite_alt</span>
                  <span className="font-['Manrope'] text-xs text-[#00261e] font-bold">Raw Pings Only</span>
                </div>
                <span className="font-['Manrope'] text-xs bg-white px-2 py-1 rounded text-[#404945] font-semibold">
                  Linear Interpolation: Blocked
                </span>
              </div>
            </div>

            {/* Rule 3 */}
            <div className="bg-white rounded-2xl p-6 shadow-sm flex flex-col justify-between gap-6 border border-[#c0c8c4]/30">
              <div className="flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <span className="font-['Sora'] text-[10px] font-bold bg-[#ddf3e9] text-[#00261e] px-2.5 py-1 rounded">
                    RULE 03
                  </span>
                  <span className="font-['Sora'] text-[10px] font-bold text-[#00261e]">
                    DUAL-PARTY CLOSE
                  </span>
                </div>
                <h3 className="font-['Sora'] text-xl font-semibold text-[#00261e]">
                  "'Fix Proposed' ≠ 'Resolved'"
                </h3>
                <p className="font-['Manrope'] text-sm text-[#404945] leading-relaxed">
                  A contractor or ward officer cannot close an overflow grievance unilaterally. A ticket moves to proposed status until the citizen or community inspector verifies clean conditions via photo stamp.
                </p>
              </div>
              <div className="bg-[#e2f9ef] p-3.5 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#00261e] text-[20px]">how_to_reg</span>
                  <span className="font-['Manrope'] text-xs text-[#00261e] font-bold">Citizen Veto Active</span>
                </div>
                <span className="font-['Manrope'] text-xs bg-white px-2 py-1 rounded text-[#404945] font-semibold">
                  48h Verification Window
                </span>
              </div>
            </div>

            {/* Rule 4 */}
            <div className="bg-white rounded-2xl p-6 shadow-sm flex flex-col justify-between gap-6 border border-[#c0c8c4]/30">
              <div className="flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <span className="font-['Sora'] text-[10px] font-bold bg-[#ddf3e9] text-[#00261e] px-2.5 py-1 rounded">
                    RULE 04
                  </span>
                  <span className="font-['Sora'] text-[10px] font-bold text-[#00261e]">
                    LEDGER AUDIT
                  </span>
                </div>
                <h3 className="font-['Sora'] text-xl font-semibold text-[#00261e]">
                  "Clean-Loop Tracked vs Municipal Filed"
                </h3>
                <p className="font-['Manrope'] text-sm text-[#404945] leading-relaxed">
                  Clear distinction between platform-level civic complaints and formal municipal gazetted dockets. Every complaint provides a public tracking hash and government ticket bridge number.
                </p>
              </div>
              <div className="bg-[#e2f9ef] p-3.5 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#00261e] text-[20px]">receipt_long</span>
                  <span className="font-['Manrope'] text-xs text-[#00261e] font-bold">Civic Ledger Audit</span>
                </div>
                <button
                  onClick={() => setActiveTab('data-honesty')}
                  className="font-['Manrope'] text-xs bg-white hover:bg-[#ddf3e9] px-2 py-1 rounded text-[#00261e] font-semibold transition-colors"
                >
                  SHA-256 Public Proofs →
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 4: 6 CORE FEATURE TILES */}
      <section className="w-full bg-[#e2f9ef] px-4 md:px-8 lg:px-12 py-16">
        <div className="max-w-7xl mx-auto flex flex-col gap-12">
          <div className="flex flex-col gap-2 text-center max-w-3xl mx-auto">
            <span className="font-['Sora'] text-[11px] font-bold text-[#00261e] uppercase tracking-wider">
              Engineered Capabilities
            </span>
            <h2 className="font-['Sora'] text-2xl sm:text-3xl font-semibold text-[#00261e] tracking-tight">
              {t.capabilitiesTitle}
            </h2>
            <p className="font-['Manrope'] text-base text-[#404945]">
              Built for high-friction metropolitan environments with erratic internet, varied local packaging materials, and rigorous SLA penalties.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Feature 1 */}
            <div
              onClick={() => setActiveTab('citizen-app')}
              className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between gap-6 group cursor-pointer border border-[#c0c8c4]/30"
            >
              <div className="flex flex-col gap-3">
                <div className="w-12 h-12 rounded-xl bg-[#d7ede3] flex items-center justify-center text-[#00261e] group-hover:bg-[#0b3d32] group-hover:text-[#c5f26a] transition-colors">
                  <span className="material-symbols-outlined text-[26px]">center_focus_strong</span>
                </div>
                <h3 className="font-['Sora'] text-xl font-semibold text-[#00261e]">
                  Camera AI Item Classifier
                </h3>
                <p className="font-['Manrope'] text-sm text-[#404945] leading-relaxed">
                  Instant edge inference scans packaging, labels, and organic textures. Immediately returns the exact bin channel, rinse/prep protocols, and local ward compliance notices.
                </p>
              </div>
              <div className="pt-2 flex items-center gap-2 font-['Manrope'] text-xs font-bold text-[#00261e]">
                <span className="material-symbols-outlined text-[16px] text-[#4a6700]">check_circle</span>
                <span>Sub-second On-Device Classification</span>
              </div>
            </div>

            {/* Feature 2 */}
            <div
              onClick={() => setActiveTab('citizen-app')}
              className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between gap-6 group cursor-pointer border border-[#c0c8c4]/30"
            >
              <div className="flex flex-col gap-3">
                <div className="w-12 h-12 rounded-xl bg-[#d7ede3] flex items-center justify-center text-[#00261e] group-hover:bg-[#0b3d32] group-hover:text-[#c5f26a] transition-colors">
                  <span className="material-symbols-outlined text-[26px]">recycling</span>
                </div>
                <h3 className="font-['Sora'] text-xl font-semibold text-[#00261e]">
                  6-Stream Segregation Engine
                </h3>
                <p className="font-['Manrope'] text-sm text-[#404945] leading-relaxed">
                  Distinct protocols for Wet, Dry, E-Waste, Domestic Hazardous, Sanitary, and Reuse. Prevents cross-contamination at source and integrates with authorized regional recyclers.
                </p>
              </div>
              {/* 6 color pill chips */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                <span className="font-['Sora'] text-[10px] font-bold px-2 py-0.5 rounded text-white bg-[#2E9E5B]">
                  Wet
                </span>
                <span className="font-['Sora'] text-[10px] font-bold px-2 py-0.5 rounded text-white bg-[#2D6CDF]">
                  Dry
                </span>
                <span className="font-['Sora'] text-[10px] font-bold px-2 py-0.5 rounded text-white bg-[#7B4FD6]">
                  E-Waste
                </span>
                <span className="font-['Sora'] text-[10px] font-bold px-2 py-0.5 rounded text-white bg-[#D9402F]">
                  Hazardous
                </span>
                <span className="font-['Sora'] text-[10px] font-bold px-2 py-0.5 rounded text-white bg-[#E08A00]">
                  Sanitary
                </span>
                <span className="font-['Sora'] text-[10px] font-bold px-2 py-0.5 rounded text-white bg-[#0E8F9B]">
                  Reuse
                </span>
              </div>
            </div>

            {/* Feature 3 */}
            <div
              onClick={() => setActiveTab('municipalities')}
              className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between gap-6 group cursor-pointer border border-[#c0c8c4]/30"
            >
              <div className="flex flex-col gap-3">
                <div className="w-12 h-12 rounded-xl bg-[#d7ede3] flex items-center justify-center text-[#00261e] group-hover:bg-[#0b3d32] group-hover:text-[#c5f26a] transition-colors">
                  <span className="material-symbols-outlined text-[26px]">analytics</span>
                </div>
                <h3 className="font-['Sora'] text-xl font-semibold text-[#00261e]">
                  Real-Time Ward Cleanliness Index
                </h3>
                <p className="font-['Manrope'] text-sm text-[#404945] leading-relaxed">
                  Honest scoring computed from Material Recovery Facility (MRF) optical purity inspections and weighbridge gross loads, not speculative self-reporting.
                </p>
              </div>
              <div className="pt-2 flex items-center gap-2 font-['Manrope'] text-xs font-bold text-[#00261e]">
                <span className="material-symbols-outlined text-[16px] text-[#4a6700]">tune</span>
                <span>Ward Purity Calibrated Daily</span>
              </div>
            </div>

            {/* Feature 4 */}
            <div
              onClick={() => setActiveTab('municipalities')}
              className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between gap-6 group cursor-pointer border border-[#c0c8c4]/30"
            >
              <div className="flex flex-col gap-3">
                <div className="w-12 h-12 rounded-xl bg-[#d7ede3] flex items-center justify-center text-[#00261e] group-hover:bg-[#0b3d32] group-hover:text-[#c5f26a] transition-colors">
                  <span className="material-symbols-outlined text-[26px]">schedule</span>
                </div>
                <h3 className="font-['Sora'] text-xl font-semibold text-[#00261e]">
                  GPS-Honest Collection Timetables
                </h3>
                <p className="font-['Manrope'] text-sm text-[#404945] leading-relaxed">
                  Dynamic alerts based on genuine truck telemetry. Citizens receive audio chimes when collection vehicles turn into their specific gully, ending hours of waiting.
                </p>
              </div>
              <div className="pt-2 flex items-center gap-2 font-['Manrope'] text-xs font-bold text-[#00261e]">
                <span className="material-symbols-outlined text-[16px] text-[#4a6700]">sensors</span>
                <span>Real-time Lane Proximity Triggers</span>
              </div>
            </div>

            {/* Feature 5 */}
            <div
              onClick={() => setActiveTab('citizen-app')}
              className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between gap-6 group cursor-pointer border border-[#c0c8c4]/30"
            >
              <div className="flex flex-col gap-3">
                <div className="w-12 h-12 rounded-xl bg-[#d7ede3] flex items-center justify-center text-[#00261e] group-hover:bg-[#0b3d32] group-hover:text-[#c5f26a] transition-colors">
                  <span className="material-symbols-outlined text-[26px]">wifi_off</span>
                </div>
                <h3 className="font-['Sora'] text-xl font-semibold text-[#00261e]">
                  Offline-First Grievance Reporting
                </h3>
                <p className="font-['Manrope'] text-sm text-[#404945] leading-relaxed">
                  Engineered with browser IndexedDB caching. Document overflowing garbage points, snap photos, and attach GPS coordinates with no network; syncs silently once signal resumes.
                </p>
              </div>
              <div className="pt-2 flex items-center gap-2 font-['Manrope'] text-xs font-bold text-[#00261e]">
                <span className="material-symbols-outlined text-[16px] text-[#4a6700]">cloud_sync</span>
                <span>Zero Data Loss on 2G Connections</span>
              </div>
            </div>

            {/* Feature 6 */}
            <div
              onClick={() => setActiveTab('municipalities')}
              className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between gap-6 group cursor-pointer border border-[#c0c8c4]/30"
            >
              <div className="flex flex-col gap-3">
                <div className="w-12 h-12 rounded-xl bg-[#d7ede3] flex items-center justify-center text-[#00261e] group-hover:bg-[#0b3d32] group-hover:text-[#c5f26a] transition-colors">
                  <span className="material-symbols-outlined text-[26px]">dashboard_customize</span>
                </div>
                <h3 className="font-['Sora'] text-xl font-semibold text-[#00261e]">
                  Municipal Command Center
                </h3>
                <p className="font-['Manrope'] text-sm text-[#404945] leading-relaxed">
                  Geospatial hot-spot clustering, automated compactor re-dispatching, and contractor penalty tracking. Integrates seamlessly into existing municipal ERPs via open Webhooks.
                </p>
              </div>
              <div className="pt-2 flex items-center gap-2 font-['Manrope'] text-xs font-bold text-[#00261e]">
                <span className="material-symbols-outlined text-[16px] text-[#4a6700]">assignment_turned_in</span>
                <span>Contractor SLA Enforced</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 5: 3-STEP CITIZEN WORKFLOW */}
      <section className="w-full bg-[#e8fef4] px-4 md:px-8 lg:px-12 py-16">
        <div className="max-w-7xl mx-auto flex flex-col gap-12">
          <div className="flex flex-col gap-2 text-center md:text-left max-w-2xl">
            <span className="font-['Sora'] text-[11px] font-bold text-[#00261e] uppercase tracking-wider">
              Simplicity at the Bin
            </span>
            <h2 className="font-['Sora'] text-2xl sm:text-3xl font-semibold text-[#00261e] tracking-tight">
              {t.stepsTitle}
            </h2>
            <p className="font-['Manrope'] text-base text-[#404945]">
              No manual PDF searching, no memorizing ambiguous municipal rules. Accurate bin guidance in seconds.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative">
            {/* Step 1 */}
            <div className="bg-white rounded-2xl p-6 shadow-sm flex flex-col gap-4 border border-[#c0c8c4]/30">
              <div className="flex items-center justify-between">
                <span className="w-10 h-10 rounded-full bg-[#0b3d32] text-[#c5f26a] flex items-center justify-center font-['Sora'] text-lg font-bold">
                  1
                </span>
                <span className="material-symbols-outlined text-[#00261e] text-[28px]">photo_camera</span>
              </div>
              <div className="flex flex-col gap-2">
                <h3 className="font-['Sora'] text-xl font-semibold text-[#00261e]">Scan or Describe</h3>
                <p className="font-['Manrope'] text-sm text-[#404945] leading-relaxed">
                  Point your smartphone camera at the item or type its name in English, Hindi, or Marathi. Clean-Loop recognizes mixed materials instantly.
                </p>
              </div>
              <div className="mt-auto bg-[#ddf3e9] p-3 rounded-xl flex items-center gap-2 text-[#404945] font-['Manrope'] text-xs">
                <span className="material-symbols-outlined text-[18px] text-[#00261e]">mic</span>
                <span>Voice input supported for senior citizens</span>
              </div>
            </div>

            {/* Step 2 */}
            <div className="bg-white rounded-2xl p-6 shadow-sm flex flex-col gap-4 border border-[#c0c8c4]/30">
              <div className="flex items-center justify-between">
                <span className="w-10 h-10 rounded-full bg-[#0b3d32] text-[#c5f26a] flex items-center justify-center font-['Sora'] text-lg font-bold">
                  2
                </span>
                <span className="material-symbols-outlined text-[#00261e] text-[28px]">rule</span>
              </div>
              <div className="flex flex-col gap-2">
                <h3 className="font-['Sora'] text-xl font-semibold text-[#00261e]">Get Verified Instructions</h3>
                <p className="font-['Manrope'] text-sm text-[#404945] leading-relaxed">
                  See the exact colored bin container, whether rinsing or folding is mandatory, and special safety alerts for razor blades, glass, or batteries.
                </p>
              </div>
              <div className="mt-auto bg-[#ddf3e9] p-3 rounded-xl flex items-center gap-2 text-[#404945] font-['Manrope'] text-xs">
                <span className="material-symbols-outlined text-[18px] text-[#4a6700]">verified</span>
                <span>Cites current Ward by-law & penalty tier</span>
              </div>
            </div>

            {/* Step 3 */}
            <div className="bg-white rounded-2xl p-6 shadow-sm flex flex-col gap-4 border border-[#c0c8c4]/30">
              <div className="flex items-center justify-between">
                <span className="w-10 h-10 rounded-full bg-[#0b3d32] text-[#c5f26a] flex items-center justify-center font-['Sora'] text-lg font-bold">
                  3
                </span>
                <span className="material-symbols-outlined text-[#00261e] text-[28px]">trending_up</span>
              </div>
              <div className="flex flex-col gap-2">
                <h3 className="font-['Sora'] text-xl font-semibold text-[#00261e]">Track Community Impact</h3>
                <p className="font-['Manrope'] text-sm text-[#404945] leading-relaxed">
                  Watch your neighborhood purity score climb. Track the exact truck arrival time and receive monthly civic cleanliness badges.
                </p>
              </div>
              <div className="mt-auto bg-[#ddf3e9] p-3 rounded-xl flex items-center gap-2 text-[#404945] font-['Manrope'] text-xs">
                <span className="material-symbols-outlined text-[18px] text-[#00261e]">emoji_events</span>
                <span>Convert civic points to municipal rebates</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 6: INTERACTIVE LIVE RULE EXPLORER */}
      <section className="w-full bg-[#e2f9ef] px-4 md:px-8 lg:px-12 py-16">
        <div className="max-w-7xl mx-auto flex flex-col gap-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div className="flex flex-col gap-2 max-w-2xl">
              <span className="font-['Sora'] text-[11px] font-bold text-[#00261e] uppercase tracking-wider">
                Interactive Live Test
              </span>
              <h2 className="font-['Sora'] text-2xl sm:text-3xl font-semibold text-[#00261e] tracking-tight">
                {t.testEngineTitle}
              </h2>
              <p className="font-['Manrope'] text-base text-[#404945]">
                Click any common tricky household waste item below or type a query to inspect the verified categorization rules and preparation directives.
              </p>
            </div>
            <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-full shadow-sm text-[#00261e] font-['Manrope'] text-xs font-semibold border border-[#c0c8c4]/30">
              <span className="w-2 h-2 rounded-full bg-[#4a6700]"></span>
              <span>By-Law DB: Mumbai SWM 2024 Rev</span>
            </div>
          </div>

          {/* Search + Badges Bar */}
          <div className="flex flex-col gap-4">
            <div className="flex flex-wrap items-center gap-2.5">
              {(['coconut', 'blister', 'milk', 'battery', 'pad'] as const).map((key) => {
                const item = WASTE_RULES_DATABASE[key];
                const isActive = selectedRuleKey === key;
                return (
                  <button
                    key={key}
                    onClick={() => setSelectedRuleKey(key)}
                    className={`px-4 py-2 rounded-full font-['Manrope'] text-sm transition-all flex items-center gap-1.5 ${
                      isActive
                        ? 'bg-[#0b3d32] text-[#c5f26a] shadow-sm font-bold'
                        : 'bg-white text-[#00261e] hover:bg-[#d1e8de] border border-[#c0c8c4]/20'
                    }`}
                    type="button"
                  >
                    <span>{item.icon}</span>
                    <span>{item.name}</span>
                  </button>
                );
              })}

              {/* Extra bonus items toggle */}
              <button
                onClick={() => setSelectedRuleKey('styrofoam')}
                className={`px-4 py-2 rounded-full font-['Manrope'] text-sm transition-all flex items-center gap-1.5 ${
                  selectedRuleKey === 'styrofoam'
                    ? 'bg-[#0b3d32] text-[#c5f26a] shadow-sm font-bold'
                    : 'bg-white text-[#00261e] hover:bg-[#d1e8de] border border-[#c0c8c4]/20'
                }`}
              >
                <span>📦</span>
                <span>Thermocol</span>
              </button>
            </div>

            {/* Quick search input */}
            <form onSubmit={handleSearchItem} className="flex items-center gap-2 max-w-md">
              <div className="relative flex-1">
                <span className="material-symbols-outlined absolute left-3 top-2.5 text-[#404945] text-[18px]">
                  search
                </span>
                <input
                  type="text"
                  placeholder="Search another item (e.g. banana peel, cable, glass)..."
                  value={customSearchQuery}
                  onChange={(e) => setCustomSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-white rounded-xl border border-[#c0c8c4]/40 text-[#0c1f19] focus:outline-none focus:border-[#0b3d32]"
                />
              </div>
              <button
                type="submit"
                className="bg-[#0b3d32] text-[#c5f26a] px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold font-['Manrope']"
              >
                Lookup
              </button>
            </form>
          </div>

          {/* Interactive Output Display Card */}
          <div className="bg-white rounded-2xl p-6 md:p-8 shadow-lg flex flex-col md:flex-row gap-8 items-start justify-between border border-[#c0c8c4]/30">
            <div className="flex flex-col gap-4 flex-1">
              <div className="flex items-center gap-3">
                <span
                  className="px-3 py-1 rounded-full text-white font-['Sora'] text-[10px] font-bold uppercase tracking-wider shadow-sm"
                  style={{ backgroundColor: activeRule.streamColor }}
                >
                  {activeRule.streamBadge}
                </span>
                <span className="font-['Sora'] text-[10px] text-[#404945] font-semibold">
                  {activeRule.confidence}
                </span>
              </div>

              <div className="flex flex-col gap-1">
                <h3 className="font-['Sora'] text-2xl font-bold text-[#00261e]">
                  {activeRule.title}
                </h3>
                <p className="font-['Manrope'] text-sm text-[#404945] leading-relaxed">
                  {activeRule.desc}
                </p>
              </div>

              {/* Instructions Details List */}
              <div className="bg-[#e2f9ef] p-4 rounded-xl flex flex-col gap-2.5">
                <div className="font-['Manrope'] text-xs text-[#00261e] font-bold">
                  Preparation & Handling Steps:
                </div>
                <ul className="flex flex-col gap-1.5 font-['Manrope'] text-xs text-[#0c1f19]">
                  {activeRule.steps.map((step, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="material-symbols-outlined text-[16px] text-[#4a6700] mt-0.5">
                        check_circle
                      </span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Source Citation Stamp */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-2 text-[#404945] font-['Manrope'] text-xs">
                <div className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px] text-[#00261e]">auto_stories</span>
                  <span>{activeRule.citation}</span>
                </div>
                <span className="font-['Sora'] text-[10px] font-bold bg-[#ddf3e9] px-2 py-0.5 rounded text-[#00261e]">
                  Verified Municipal Rule
                </span>
              </div>
            </div>

            {/* Bin Graphic Visualizer Component */}
            <div className="w-full md:w-72 bg-[#e2f9ef] rounded-2xl p-6 flex flex-col items-center justify-center gap-3 self-stretch text-center border border-[#c0c8c4]/20">
              <div
                className="w-20 h-20 rounded-2xl flex items-center justify-center shadow-inner"
                style={{ backgroundColor: activeRule.binBg, color: activeRule.binColor }}
              >
                <span className="material-symbols-outlined text-[42px]">{activeRule.binIcon}</span>
              </div>
              <div className="flex flex-col">
                <span className="font-['Sora'] text-[10px] text-[#404945] uppercase font-bold">
                  Target Destination
                </span>
                <span className="font-['Sora'] text-lg font-bold text-[#00261e]">
                  {activeRule.binName}
                </span>
              </div>
              <div className="w-full bg-white p-2.5 rounded-xl font-['Manrope'] text-xs text-[#00261e]">
                Next Collection: <strong>{activeRule.collectionTime}</strong>
              </div>
              {activeRule.penaltyTier && (
                <div className="font-['Manrope'] text-[11px] text-[#ba1a1a] font-semibold">
                  Non-compliance fine: {activeRule.penaltyTier}
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 7: MUNICIPAL GOVERNANCE & OPERATIONS */}
      <section className="w-full bg-[#e8fef4] px-4 md:px-8 lg:px-12 py-16">
        <div className="max-w-7xl mx-auto flex flex-col gap-12">
          <div className="flex flex-col gap-2 max-w-3xl">
            <span className="font-['Sora'] text-[11px] font-bold text-[#00261e] uppercase tracking-wider">
              Enterprise Municipal Grade
            </span>
            <h2 className="font-['Sora'] text-2xl sm:text-3xl font-semibold text-[#00261e] tracking-tight">
              {t.builtForTitle}
            </h2>
            <p className="font-['Manrope'] text-base text-[#404945]">
              Clean-Loop eliminates friction between sanitary inspectors, outsourced fleet contractors, and central monitoring rooms through automated verifiable dispatch.
            </p>
          </div>

          {/* Stats Cluster */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-2xl shadow-sm flex flex-col gap-2 border border-[#c0c8c4]/30">
              <span className="font-['Sora'] text-[11px] text-[#404945] uppercase font-bold">
                Monthly Grievance Audit
              </span>
              <div className="font-['Sora'] text-2xl md:text-3xl font-bold text-[#00261e]">
                142 Active
              </div>
              <div className="font-['Manrope'] text-sm text-[#404945]">
                Ward complaints resolved with citizen photo verification before sign-off.
              </div>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-sm flex flex-col gap-2 border border-[#c0c8c4]/30">
              <span className="font-['Sora'] text-[11px] text-[#404945] uppercase font-bold">
                SLA Velocity
              </span>
              <div className="font-['Sora'] text-2xl md:text-3xl font-bold text-[#4a6700]">
                78.4%
              </div>
              <div className="font-['Manrope'] text-sm text-[#404945]">
                24-hour rapid resolution rate across micro-dump hot spots.
              </div>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-sm flex flex-col gap-2 border border-[#c0c8c4]/30">
              <span className="font-['Sora'] text-[11px] text-[#404945] uppercase font-bold">
                Landfill Diversion
              </span>
              <div className="font-['Sora'] text-2xl md:text-3xl font-bold text-[#00261e]">
                34% Reduction
              </div>
              <div className="font-['Manrope'] text-sm text-[#404945]">
                Drop in mixed unsegregated waste loads tipped at regional dumping grounds.
              </div>
            </div>
          </div>

          {/* Governance Deep-Dive Trio */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 pt-2">
            <div className="bg-white rounded-2xl p-6 shadow-sm flex flex-col gap-3 border border-[#c0c8c4]/30">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#d7ede3] flex items-center justify-center text-[#00261e]">
                  <span className="material-symbols-outlined text-[22px]">admin_panel_settings</span>
                </div>
                <h3 className="font-['Sora'] text-lg font-semibold text-[#00261e]">
                  Role-Guarded FastAPI Core
                </h3>
              </div>
              <p className="font-['Manrope'] text-sm text-[#404945] leading-relaxed">
                Granular RBAC ensures field supervisors can only sign off their assigned beats, while municipal commissioners view cross-ward comparative aggregates without contractor data tampering.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-sm flex flex-col gap-3 border border-[#c0c8c4]/30">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#d7ede3] flex items-center justify-center text-[#00261e]">
                  <span className="material-symbols-outlined text-[22px]">local_shipping</span>
                </div>
                <h3 className="font-['Sora'] text-lg font-semibold text-[#00261e]">
                  Automated Compactor Routing
                </h3>
              </div>
              <p className="font-['Manrope'] text-sm text-[#404945] leading-relaxed">
                Dynamic re-routing algorithms automatically divert high-capacity compactor trucks to wards experiencing sudden organic surges or market-day disposal peaks.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-sm flex flex-col gap-3 border border-[#c0c8c4]/30">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#d7ede3] flex items-center justify-center text-[#00261e]">
                  <span className="material-symbols-outlined text-[22px]">published_with_changes</span>
                </div>
                <h3 className="font-['Sora'] text-lg font-semibold text-[#00261e]">
                  Citizen Confirmation Loops
                </h3>
              </div>
              <p className="font-['Manrope'] text-sm text-[#404945] leading-relaxed">
                Contractors cannot trigger payment disbursement without citizen verification of bin clearances. Public ratings directly tie into contractor municipal penalty clauses.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 8: CTA FOOTER INTAKE */}
      <section className="w-full bg-[#0b3d32] text-white px-4 md:px-8 lg:px-12 py-16 relative overflow-hidden">
        <div className="absolute -right-20 -bottom-20 w-80 h-80 rounded-full bg-[#c5f26a]/10 blur-2xl pointer-events-none"></div>

        <div className="max-w-5xl mx-auto flex flex-col items-center text-center gap-8 relative z-10">
          <div className="inline-flex items-center gap-2 bg-[#003e2f] px-4 py-1.5 rounded-full">
            <span className="w-2 h-2 rounded-full bg-[#c5f26a]"></span>
            <span className="font-['Sora'] text-[11px] font-bold text-[#c5f26a] uppercase tracking-wider">
              Metropolitan Deployment Sandbox
            </span>
          </div>

          <div className="flex flex-col gap-3 max-w-3xl">
            <h2 className="font-['Sora'] text-2xl sm:text-4xl lg:text-[44px] text-white font-bold tracking-tight leading-tight">
              {t.readyDeployTitle}
            </h2>
            <p className="font-['Manrope'] text-base sm:text-lg text-[#bceddc] leading-relaxed">
              Pilot the platform across a single sanitation ward in under 14 days. Full integration with weighbridge telemetry, open citizen web-apps, and automated contractor billing audits.
            </p>
          </div>

          {/* Action Cluster */}
          <div className="flex flex-wrap items-center justify-center gap-4">
            <button
              onClick={onOpenPilotModal}
              className="inline-flex items-center gap-2 bg-[#c5f26a] text-[#4f6e00] hover:bg-[#aad551] px-8 py-4 rounded-xl font-['Manrope'] text-sm font-bold shadow-lg transition-all active:scale-95"
              type="button"
            >
              <span className="material-symbols-outlined text-[20px]">handshake</span>
              {t.requestPilot}
            </button>

            <button
              onClick={() => setActiveTab('data-honesty')}
              className="inline-flex items-center gap-2 bg-[#003e2f] text-white hover:bg-[#00261e] px-6 py-4 rounded-xl font-['Manrope'] text-sm font-semibold transition-all"
              type="button"
            >
              <span className="material-symbols-outlined text-[20px]">terminal</span>
              View API & MSW Specs
            </button>

            <button
              onClick={() => setActiveTab('citizen-app')}
              className="inline-flex items-center gap-2 bg-[#0b3d32] border border-[#bceddc]/40 text-[#bceddc] hover:text-white px-6 py-4 rounded-xl font-['Manrope'] text-sm font-semibold transition-all"
              type="button"
            >
              <span className="material-symbols-outlined text-[20px]">download</span>
              Citizen Progressive App
            </button>
          </div>

          {/* Protocol Compliance Micro-Banner */}
          <div className="pt-4 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-[#a1d0c1] font-['Manrope'] text-xs">
            <span>Open Civic GeoJSON API</span>
            <span>•</span>
            <span>ISO 27001 Certified Infrastructure</span>
            <span>•</span>
            <span>Multilingual Engine (English, Hindi, Marathi)</span>
          </div>
        </div>
      </section>
    </div>
  );
};
