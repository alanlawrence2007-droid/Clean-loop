/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ActiveTab, Language } from './types';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { PlatformView } from './components/PlatformView';
import { CitizenAppView } from './components/CitizenAppView';
import { MunicipalCommandView } from './components/MunicipalCommandView';
import { DataHonestyView } from './components/DataHonestyView';
import { LiveDemoView } from './components/LiveDemoView';
import { DemoModal, PilotModal, PointsToast } from './components/Modals';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('platform');
  const [language, setLanguage] = useState<Language>('en');
  const [citizenPoints, setCitizenPoints] = useState<number>(140);
  const [demoModalOpen, setDemoModalOpen] = useState<boolean>(false);
  const [pilotModalOpen, setPilotModalOpen] = useState<boolean>(false);
  const [toast, setToast] = useState<{
    isOpen: boolean;
    points: number;
    message: string;
  }>({
    isOpen: false,
    points: 0,
    message: ''
  });

  const handleTabChange = (tab: ActiveTab) => {
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAwardPoints = (pts: number, reason: string) => {
    setCitizenPoints((prev) => prev + pts);
    setToast({
      isOpen: true,
      points: pts,
      message: reason
    });
    setTimeout(() => {
      setToast((prev) => ({ ...prev, isOpen: false }));
    }, 4500);
  };

  return (
    <div className="bg-[#e8fef4] min-h-screen text-[#0c1f19] flex flex-col font-['Manrope'] selection:bg-[#c5f26a] selection:text-[#00261e]">
      {/* Fixed Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={handleTabChange}
        language={language}
        setLanguage={setLanguage}
        onOpenPilotModal={() => setPilotModalOpen(true)}
        citizenPoints={citizenPoints}
      />

      {/* Main View Area */}
      <main className="w-full pt-20 flex-1">
        {activeTab === 'platform' && (
          <PlatformView
            setActiveTab={handleTabChange}
            language={language}
            onOpenDemoModal={() => setDemoModalOpen(true)}
            onOpenPilotModal={() => setPilotModalOpen(true)}
            onAwardPoints={handleAwardPoints}
          />
        )}

        {activeTab === 'citizen-app' && (
          <CitizenAppView
            citizenPoints={citizenPoints}
            onAwardPoints={handleAwardPoints}
            onOpenPilotModal={() => setPilotModalOpen(true)}
          />
        )}

        {activeTab === 'municipalities' && <MunicipalCommandView />}

        {activeTab === 'data-honesty' && <DataHonestyView />}

        {activeTab === 'live-demo' && (
          <LiveDemoView
            onAwardPoints={handleAwardPoints}
            onOpenPilotModal={() => setPilotModalOpen(true)}
          />
        )}
      </main>

      {/* Footer */}
      <Footer
        setActiveTab={handleTabChange}
        onOpenPilotModal={() => setPilotModalOpen(true)}
      />

      {/* Modals & Notifications */}
      <DemoModal
        isOpen={demoModalOpen}
        onClose={() => setDemoModalOpen(false)}
      />

      <PilotModal
        isOpen={pilotModalOpen}
        onClose={() => setPilotModalOpen(false)}
      />

      {toast.isOpen && (
        <PointsToast
          pointsEarned={toast.points}
          message={toast.message}
          onClose={() => setToast((prev) => ({ ...prev, isOpen: false }))}
        />
      )}
    </div>
  );
}
