export type WasteStreamType = 'wet' | 'dry' | 'ewaste' | 'hazardous' | 'sanitary' | 'reuse';

export interface WasteItemRule {
  id: string;
  name: string;
  localName?: string;
  marathiName?: string;
  hindiName?: string;
  icon: string;
  stream: WasteStreamType;
  streamBadge: string;
  streamColor: string;
  confidence: string;
  title: string;
  desc: string;
  steps: string[];
  citation: string;
  binName: string;
  binIcon: string;
  binBg: string;
  binColor: string;
  collectionTime: string;
  penaltyTier?: string;
  image?: string;
}

export interface CompactorTruck {
  id: string;
  registrationNumber: string;
  driver: string;
  ward: string;
  sector: string;
  status: 'on_route' | 'weighbridge_transit' | 'signal_stall' | 'dumping';
  etaMinutes: number;
  clearedPercentage: number;
  activeLane: string;
  lastPingTimestamp: string;
  isGhostFleetWarning: boolean;
  wetPurityScore: number;
  nextCheckpoint: string;
}

export interface GrievanceTicket {
  id: string;
  hash: string;
  municipalDocket: string;
  ward: string;
  location: string;
  category: string;
  reportedAt: string;
  status: 'reported' | 'assigned' | 'fix_proposed' | 'verified_resolved';
  citizenPhotoUrl: string;
  contractorPhotoUrl?: string;
  citizenApproved: boolean;
  inspectorApproved: boolean;
  disputeNotes?: string;
}

export interface WardMetric {
  wardId: string;
  name: string;
  segregationRate: number;
  purityScore: number;
  dailyTonnage: number;
  divertedTonnage: number;
  slaResolutionRate: number;
  activeTrucks: number;
  openGrievances: number;
}

export type Language = 'en' | 'hi' | 'mr';

export type ActiveTab = 'platform' | 'citizen-app' | 'municipalities' | 'data-honesty' | 'live-demo';
