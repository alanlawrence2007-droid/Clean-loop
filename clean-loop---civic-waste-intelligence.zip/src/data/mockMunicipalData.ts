import { CompactorTruck, GrievanceTicket, WardMetric } from '../types';

export const INITIAL_TRUCKS: CompactorTruck[] = [
  {
    id: 'trk-4412',
    registrationNumber: 'MH-02-CW-4412',
    driver: 'Ramesh Patil (Emp #4821)',
    ward: 'Ward 12 (K/West)',
    sector: 'Sector 9 Compactor',
    status: 'on_route',
    etaMinutes: 6,
    clearedPercentage: 65,
    activeLane: 'Lane 4A (Wet Stream Audit: 92% purity)',
    lastPingTimestamp: '10 seconds ago (Raw GPS Ping: 19.1136° N, 72.8258° E)',
    isGhostFleetWarning: false,
    wetPurityScore: 92,
    nextCheckpoint: 'Hub Ghatkopar 14:30 IST'
  },
  {
    id: 'trk-8821',
    registrationNumber: 'MH-02-CW-8821',
    driver: 'Santosh Kulkarni (Emp #5109)',
    ward: 'Ward 12 (K/West)',
    sector: 'Sector 4 Beachfront Beat',
    status: 'on_route',
    etaMinutes: 14,
    clearedPercentage: 42,
    activeLane: 'Juhu Tara Road Beat #2',
    lastPingTimestamp: '18 seconds ago (Raw GPS Ping: 19.0984° N, 72.8271° E)',
    isGhostFleetWarning: false,
    wetPurityScore: 88,
    nextCheckpoint: 'MRF-3 Weighbridge 15:10 IST'
  },
  {
    id: 'trk-1904',
    registrationNumber: 'MH-02-CW-1904',
    driver: 'Vinod Sharma (Contractor Fleet)',
    ward: 'Ward 12 (K/West)',
    sector: 'Sector 11 Commercial Market',
    status: 'signal_stall',
    etaMinutes: 28,
    clearedPercentage: 78,
    activeLane: 'Andheri West Market Lane',
    lastPingTimestamp: 'Signal Lost 9 mins ago (Honest Status: Stalled, no interpolated ghost route)',
    isGhostFleetWarning: true,
    wetPurityScore: 79,
    nextCheckpoint: 'Underground Tunnel Transit'
  }
];

export const INITIAL_WARDS: WardMetric[] = [
  {
    wardId: 'W-12',
    name: 'Ward 12 (K/West - Andheri/Juhu)',
    segregationRate: 81.2,
    purityScore: 91.4,
    dailyTonnage: 184.2,
    divertedTonnage: 149.5,
    slaResolutionRate: 78.4,
    activeTrucks: 14,
    openGrievances: 18
  },
  {
    wardId: 'W-09',
    name: 'Ward 09 (H/East - Bandra/Santacruz)',
    segregationRate: 76.8,
    purityScore: 84.1,
    dailyTonnage: 152.0,
    divertedTonnage: 116.7,
    slaResolutionRate: 72.0,
    activeTrucks: 11,
    openGrievances: 24
  },
  {
    wardId: 'W-15',
    name: 'Ward 15 (P/South - Goregaon)',
    segregationRate: 69.4,
    purityScore: 78.9,
    dailyTonnage: 168.4,
    divertedTonnage: 116.8,
    slaResolutionRate: 68.1,
    activeTrucks: 12,
    openGrievances: 31
  },
  {
    wardId: 'W-04',
    name: 'Ward 04 (D Ward - Malabar Hill/Grant Rd)',
    segregationRate: 88.5,
    purityScore: 94.2,
    dailyTonnage: 112.6,
    divertedTonnage: 99.6,
    slaResolutionRate: 89.3,
    activeTrucks: 9,
    openGrievances: 7
  }
];

export const INITIAL_GRIEVANCES: GrievanceTicket[] = [
  {
    id: 'GRV-2025-0814',
    hash: 'SHA256: 7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069',
    municipalDocket: 'BMC/MSW/2025/K-W/90412',
    ward: 'Ward 12 (K/West)',
    location: 'Gulmohar Cross Rd 7, JVPD Scheme',
    category: 'Overflowing Organic Container',
    reportedAt: 'Today 09:24 IST',
    status: 'fix_proposed',
    citizenPhotoUrl: 'https://images.unsplash.com/photo-1605600659908-0ef719419d41?w=600&auto=format&fit=crop&q=80',
    contractorPhotoUrl: 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=600&auto=format&fit=crop&q=80',
    citizenApproved: false,
    inspectorApproved: true,
    disputeNotes: 'Contractor submitted clearance photo. Awaiting citizen confirmation before payment disbursement.'
  },
  {
    id: 'GRV-2025-0819',
    hash: 'SHA256: 9b2d89ca4013e2f3d61184a5582312d90ef014798a3b5c671295b9c3e412803b',
    municipalDocket: 'BMC/MSW/2025/K-W/90445',
    ward: 'Ward 12 (K/West)',
    location: 'Seven Bungalows Metro Pillar #42',
    category: 'Mixed Plastic & Debris Dumping',
    reportedAt: 'Yesterday 17:40 IST',
    status: 'verified_resolved',
    citizenPhotoUrl: 'https://images.unsplash.com/photo-1528323273322-d81458248d40?w=600&auto=format&fit=crop&q=80',
    contractorPhotoUrl: 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=600&auto=format&fit=crop&q=80',
    citizenApproved: true,
    inspectorApproved: true,
    disputeNotes: 'Citizen verified clean pavement via geotagged photo. Ticket closed permanently.'
  },
  {
    id: 'GRV-2025-0824',
    hash: 'SHA256: 3c5e8812fba6778401e4599a4c82b012479e00cd816bb4995f7823e201b1a451',
    municipalDocket: 'BMC/MSW/2025/K-W/90488',
    ward: 'Ward 12 (K/West)',
    location: 'Versova Yari Road Fish Market Corner',
    category: 'Unsegregated Wet Waste Spillage',
    reportedAt: 'Today 11:05 IST',
    status: 'assigned',
    citizenPhotoUrl: 'https://images.unsplash.com/photo-1611284446314-60a58ac0deb9?w=600&auto=format&fit=crop&q=80',
    citizenApproved: false,
    inspectorApproved: false,
    disputeNotes: 'Assigned to compactor crew #MH-02-CW-4412. ETA 35 minutes.'
  }
];
